/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   playground.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/21 15:40:53 by causilva          #+#    #+#             */
/*   Updated: 2025/05/14 18:34:51 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "mandatory/ft_printf.h"
#include <stdio.h>
/* 
int	main(void)
{
	char	string[] = "abcd";

	ft_printf("|%c|", 'A');
	printf("|%c|\n", 'A');

	ft_printf("|%s|", string);
	printf("|%s|\n", string);
	
	ft_printf("|%p|", string);
	printf("|%p|\n", string);

	ft_printf("|%d|", 1234);
	printf("|%d|\n", 1234);

	ft_printf("|%i|", 1234);
	printf("|%i|\n", 1234);
	
	ft_printf("|%u|", 1234);
	printf("|%u|\n", 1234);

	ft_printf("|%x|", 30);
	printf("|%x|\n", 30);
	
	ft_printf("|%X|", 30);
	printf("|%X|\n", 30);
	
	ft_printf("|%%|");
	printf("%%|\n");

	ft_printf("%d", ft_printf("%c%"));
	printf("\n");
	return (0);
}
 */

int	main(void)
{

	ft_printf("%12d|\n", 42);
	ft_printf("%-12d|\n", 42);
	ft_printf("%.12d|\n", 42);
	ft_printf("%012d|\n", 42);
	ft_printf("%+-12.08d|\n", 42);
	ft_printf("% +d|\n", 1);

	ft_printf("%12s|\n", "ABC");
	ft_printf("%-12s|\n", "ABC");
	ft_printf("%012s|\n", "ABC");
	ft_printf("%.12s|\n", "ABC");
	ft_printf("%#12s|\n", "ABC");
	ft_printf("% 12s|\n", "ABC");
	ft_printf("%+12s|\n", "ABC");

	ft_printf("%.0s|\n", "ABC");
	return (0);
}
