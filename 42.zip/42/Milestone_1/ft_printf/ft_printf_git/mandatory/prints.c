/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prints.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 18:35:48 by causilva          #+#    #+#             */
/*   Updated: 2025/04/30 13:12:12 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_c(unsigned char c)
{
	ft_putchar_fd(c, 1);
	return (1);
}

int	ft_print_s(char *s)
{
	if (!s)
	{
		ft_putstr_fd("(null)", 1);
		return (6);
	}
	ft_putstr_fd(s, 1);
	return (ft_strlen(s));
}

int	ft_print_p(void *ptr)
{
	if (!ptr)
	{
		ft_putstr_fd("(nil)", 1);
		return (5);
	}
	ft_putstr_fd("0x", 1);
	return (2 + ft_print_lhex((unsigned long ) ptr, 'x'));
}

int	ft_print_li(long n)
{
	if (n < -9)
	{
		ft_putchar_fd('-', 1);
		return (1 + ft_print_li(-(n / 10)) + ft_print_li(-(n % 10)));
	}
	if (n < 0)
	{
		ft_putchar_fd('-', 1);
		return (1 + ft_print_li(-n));
	}
	if (n < 10)
	{
		ft_putchar_fd(n + '0', 1);
		return (1);
	}
	return (ft_print_li(n / 10) + ft_print_li(n % 10));
}

int	ft_print_lhex(unsigned long n, char c)
{
	if (n < 16)
	{
		if (n < 10)
			ft_putchar_fd(n + '0', 1);
		else
			ft_putchar_fd((n - 10 + 'A' + (32 * (c == 'x'))), 1);
		return (1);
	}
	return (ft_print_lhex(n / 16, c) + ft_print_lhex(n % 16, c));
}
