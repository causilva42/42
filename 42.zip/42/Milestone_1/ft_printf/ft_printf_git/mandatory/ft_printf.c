/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 14:40:01 by causilva          #+#    #+#             */
/*   Updated: 2025/05/06 15:35:38 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_printf(const char *format, ...)
{
	va_list	args;
	int		total_read;
	int		total_printed;
	int		temp;

	if (!format || !ft_check_valid(format))
		return (-1);
	va_start(args, format);
	total_read = 0;
	total_printed = 0;
	while (format[total_read] != '\0')
	{
		if (format[total_read] == '%')
		{
			total_printed += ft_choose_print(format[total_read + 1], &args);
			total_read += 2;
			continue ;
		}
		temp = ft_print_pure(&format[total_read]);
		total_read += temp;
		total_printed += temp;
	}
	va_end(args);
	return (total_printed);
}

int	ft_check_valid(const char *format)
{
	int	i;

	i = 0;
	while (format[i] != '\0')
	{
		if (format[i] == '%'
			&& (format[i + 1] == '\0'
				|| !ft_strchr("cspdiuxX%", format[i + 1])
			)
		)
			return (0);
		i += 1 + (format[i] == '%');
	}
	return (1);
}

int	ft_choose_print(char c, va_list *args)
{
	if (c == 'c')
		return (ft_print_c(va_arg(*args, int)));
	else if (c == 's')
		return (ft_print_s(va_arg(*args, char *)));
	else if (c == 'p')
		return (ft_print_p(va_arg(*args, void *)));
	else if (c == 'd' || c == 'i')
		return (ft_print_li(va_arg(*args, int)));
	else if (c == 'u')
		return (ft_print_li(va_arg(*args, unsigned int)));
	else if (c == 'x' || c == 'X')
		return (ft_print_lhex(va_arg(*args, unsigned int), c));
	else if (c == '%')
		return (ft_print_c('%'));
	return (0);
}

int	ft_print_pure(const char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0' && s[i] != '%')
		i++;
	write(1, s, i);
	return (i);
}
