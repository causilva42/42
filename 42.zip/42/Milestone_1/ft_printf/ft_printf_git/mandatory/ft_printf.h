/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 18:36:23 by causilva          #+#    #+#             */
/*   Updated: 2025/05/06 15:40:54 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdlib.h>
# include <unistd.h>
# include <stdarg.h>
# include "../lib/lib.h"

//----------------------------------------------
//-----------------FT_PRINTF.C------------------
//----------------------------------------------
int	ft_printf(const char *format, ...);
int	ft_check_valid(const char *format);
int	ft_choose_print(char c, va_list *args);
int	ft_print_pure(const char *s);

//----------------------------------------------
//------------------PRINTS.C--------------------
//----------------------------------------------
int	ft_print_c(unsigned char c);
int	ft_print_s(char *s);
int	ft_print_p(void *ptr);
int	ft_print_li(long n);
int	ft_print_lhex(unsigned long n, char c);

#endif