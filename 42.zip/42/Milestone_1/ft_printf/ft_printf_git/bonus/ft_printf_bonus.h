/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_bonus.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 18:36:23 by causilva          #+#    #+#             */
/*   Updated: 2025/05/14 18:20:04 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_BONUS_H
# define FT_PRINTF_BONUS_H

# include <stdlib.h>
# include <unistd.h>
# include <stdarg.h>
# include <limits.h>
# include "../lib/lib.h"

typedef struct s_flags
{
	int		bool_minus;
	int		bool_zero;
	int		bool_hashtag;
	int		bool_space;
	int		bool_plus;
	int		bool_point;
	int		num;
	int		point;
	char	type;
}	t_flags;

typedef struct s_iocount
{
	int	read;
	int	printed;
}	t_iocount;

//----------------------------------------------
//---------------FT_PRINTF_BONUS.C--------------
//----------------------------------------------
int			ft_printf(const char *format, ...);
int			check_valid(const char *format);
t_iocount	choose_print(const char *s, va_list *args);

//----------------------------------------------
//--------------FILL_FLAGS_BONUS.C--------------
//----------------------------------------------
int			fill_flags(t_flags *flags, const char *s);
void		set_zero(t_flags *flags);
int			readstr_atoi(const char *s, int *num);

//----------------------------------------------
//----------------PRINTS_BONUS.C----------------
//----------------------------------------------
t_iocount	print_pure(const char *s);
void		print_nblanks(int n);
void		print_nzeros(int n);
int			print_c(unsigned char c, t_flags	flags);
int			print_s(char *s, t_flags	flags);
int			print_p(void *ptr, t_flags	flags);
int			print_li(long n, t_flags	flags);
int			print_lhex(unsigned long n, t_flags	flags);
void		putnbr_lhex(unsigned long n, char c);

#endif