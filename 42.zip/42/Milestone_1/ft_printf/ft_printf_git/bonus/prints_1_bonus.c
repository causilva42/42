/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prints_1_bonus.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 18:35:48 by causilva          #+#    #+#             */
/*   Updated: 2025/05/14 18:46:39 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

t_iocount	print_pure(const char *s)
{
	int	i;

	i = 0;
	while (s[i] != '\0' && s[i] != '%')
		i++;
	write(1, s, i);
	return ((t_iocount){i, i});
}

void	print_nblanks(int n)
{
	int		i;

	i = 0;
	while (i++ < n)
		ft_putchar_fd(' ', 1);
}

void	print_nzeros(int n)
{
	int		i;

	i = 0;
	while (i++ < n)
		ft_putchar_fd('0', 1);
}

int	print_c(unsigned char c, t_flags flags)
{
	if (c == '%')
	{
		ft_putchar_fd(c, 1);
		return (1);
	}
	print_nblanks((flags.num - 1) * (!flags.bool_minus));
	ft_putchar_fd(c, 1);
	print_nblanks((flags.num - 1) * (flags.bool_minus));
	return (ft_biggest(1, flags.num));
}

int	print_s(char *s, t_flags flags)
{
	int	len;

	if (!s)
	{
		if (flags.point >= 6)
		{
			print_nblanks((flags.num - 6) * (!flags.bool_minus));
			ft_putstr_fd("(null)", 1);
			print_nblanks((flags.num - 6) * (flags.bool_minus));
			return (ft_biggest(6, flags.num));
		}
		print_nblanks(flags.num);
		return (ft_biggest(0, flags.num));
	}
	len = ft_strlen(s);
	if (flags.bool_point)
		len = ft_smallest(len, flags.point);
	print_nblanks((flags.num - len) * (!flags.bool_minus));
	write(1, s, len);
	print_nblanks((flags.num - len) * (flags.bool_minus));
	return (ft_biggest(len, flags.num));
}
