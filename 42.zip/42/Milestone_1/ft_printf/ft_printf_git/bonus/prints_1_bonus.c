/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prints_1_bonus.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 18:35:48 by causilva          #+#    #+#             */
/*   Updated: 2025/05/22 17:03:34 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

int	print_c(unsigned char c, t_flags flags)
{
	return (_write(&c, 1, flags));
}

int	print_s(char *s, t_flags flags)
{
	int	len;

	if (!s)
	{
		if (flags.point >= 6)
			return (_write("(null)", 6, flags));
		return (_write("", 0, flags));
	}
	len = ft_strlen(s);
	if (flags.bool_point && flags.point < len)
		len = flags.point;
	return (_write(s, len, flags));
}

int	print_p(void *ptr, t_flags flags)
{
	if (!ptr)
		return (_write("(nil)", 5, flags));
	flags.bool_hashtag = 1;
	flags.type = 'x';
	return (print_lhex((unsigned long ) ptr, flags));
}