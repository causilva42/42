/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fill_flags_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/12 14:57:03 by causilva          #+#    #+#             */
/*   Updated: 2025/05/14 18:39:05 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

int	fill_flags(t_flags *flags, const char *s)
{
	int	i;

	set_zero(flags);
	i = 0;
	while (s[i] && ft_strchr("#-+ 0", s[i]))
	{
		if (s[i] == '#')
			flags->bool_hashtag = 1;
		else if (s[i] == '-')
			flags->bool_minus = 1;
		else if (s[i] == '+')
			flags->bool_plus = 1;
		else if (s[i] == ' ')
			flags->bool_space = 1;
		else if (s[i] == '0')
			flags->bool_zero = 1;
		i++;
	}
	i += readstr_atoi(&s[i], &(flags->num));
	if (s[i] == '.')
	{
		flags->bool_point = 1;
		flags->bool_zero = 0;
		i += 1 + readstr_atoi(&s[i + 1], &(flags->point));
	}
	if (s[i] && ft_strchr("cspdiuxX%", s[i]))
		flags->type = s[i++];
	return (i);
}

void	set_zero(t_flags *flags)
{
	flags->bool_hashtag = 0;
	flags->bool_minus = 0;
	flags->bool_plus = 0;
	flags->bool_space = 0;
	flags->bool_zero = 0;
	flags->bool_point = 0;
	flags->num = 0;
	flags->point = 0;
	flags->type = '\0';
	return ;
}

int	readstr_atoi(const char *s, int *num)
{
	int	i;

	*num = 0;
	i = 0;
	while (ft_isdigit(s[i]))
	{
		if (*num > (INT_MAX - (s[i] - '0')) / 10)
		{
			*num = -1;
			break ;
		}
		*num *= 10;
		*num += s[i] - '0';
		i++;
	}
	return (i);
}
