/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/22 14:40:01 by causilva          #+#    #+#             */
/*   Updated: 2025/05/14 18:25:13 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

int	ft_printf(const char *format, ...)
{
	va_list		args;
	t_iocount	total;
	t_iocount	temp;

	if (!format || !check_valid(format))
		return (-1);
	va_start(args, format);
	total.read = 0;
	total.printed = 0;
	while (format[total.read] != '\0')
	{
		if (format[total.read] == '%')
			temp = choose_print(&format[++total.read], &args);
		else
			temp = print_pure(&format[total.read]);
		total.read += temp.read;
		total.printed += temp.printed;
	}
	va_end(args);
	return (total.printed);
}

int	check_valid(const char *format)
{
	int		len;
	int		i;
	t_flags	flags;

	len = ft_strlen(format);
	if (len != 0 && (format[len - 1] == '%'))
		return (0);
	i = 0;
	while (i < len)
	{
		if (format[i++] == '%')
		{
			i += fill_flags(&flags, &format[i]);
			if (flags.num == -1 || flags.point == -1)
				return (0);
		}
	}
	return (1);
}

t_iocount	choose_print(const char *s, va_list *args)
{
	t_iocount	temp;
	t_flags		flags;

	temp.read = fill_flags(&flags, s);
	if (flags.type == 'c')
		temp.printed = print_c(va_arg(*args, int), flags);
	else if (flags.type == 's')
		temp.printed = print_s(va_arg(*args, char *), flags);
	else if (flags.type == 'p')
		temp.printed = print_p(va_arg(*args, void *), flags);
	else if (flags.type == 'd' || flags.type == 'i')
		temp.printed = print_li(va_arg(*args, int), flags);
	else if (flags.type == 'u')
		temp.printed = print_li(va_arg(*args, unsigned int), flags);
	else if (flags.type == 'x' || flags.type == 'X')
		temp.printed = print_lhex(va_arg(*args, unsigned int), flags);
	else if (flags.type == '%')
		temp.printed = print_c('%', flags);
	else
	{
		ft_putchar_fd('%', 1);
		return ((t_iocount){0, 1});
	}
	return (temp);
}
