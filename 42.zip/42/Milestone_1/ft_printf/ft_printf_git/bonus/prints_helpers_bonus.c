/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prints_helpers_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/22 16:13:43 by causilva          #+#    #+#             */
/*   Updated: 2025/05/22 18:12:32 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

int	print_nblanks(int n)
{
	int	i;
	int	write_return;

	i = 0;
	while (i < n)
	{
		write_return = write(1, " ", 1);
		if (write_return < 0)
			return (write_return);
		i++;
	}
		return (i);
}

int	print_nzeros(int n)
{
	int	i;
	int	write_return;

	i = 0;
	while (i < n)
	{
		write_return = write(1, "0", 1);
		if (write_return < 0)
			return (write_return);
		i++;
	}
		return (i);
}

int	_write(const void *buf, int n, t_flags flags)
{
	int	write_return[3];

	write_return[0] = print_nblanks((flags.num - n) * (!flags.bool_minus));
	if (write_return[0] < 0)
		return (write_return[0]);
	write_return[1] = write(1, buf, n);
	if (write_return[1] < 0)
		return (write_return[1]);
	write_return[2] = print_nblanks((flags.num - n) * (flags.bool_minus));
	if (write_return[2] < 0)
		return (write_return[2]);
	return (write_return[0] + write_return[1] + write_return[2]);
}

int	__write()
{
	int	num_len;
	int	extra;
	int	zeros;
	int	blanks;

	extra = ""
	if (flags.bool_hashtag && flags.type == 'x')
		extra = "0x"
	else if (flags.bool_hashtag && flags.type == 'X')
		extra = "0X"
	else if (n < 0)
		extra = "-"
	else if (flags.bool_plus)
		extra = "+"
	else if (flags.bool_space)
		extra = " "

		zeros = 0
	if (flags.bool_point)
		zeros = flags.point - num_len;
	else if (flags.bool_zero)
		zeros = flags.num - num_len - extra;
	
	blanks = flags.num - num_len - extra - zeros;
}

int	___write()
{
	int	write_return[5];

	write_return[0] = print_nblanks(blanks * (!flags.bool_minus));
	if (write_return[0] < 0)
		return (write_return[0]);
	write_return[1] = write(1, extra, ft_strlen(extra));
	if (write_return[1] < 0)
		return (write_return[1]);
	write_return[2] = print_nzeros(zeros);
	if (write_return[2] < 0)
		return (write_return[2]);
	write_return[3] = print_num;
	if (write_return[3] < 0)
		return (write_return[3]);
	write_return[4] = print_nblanks(blanks * flags.bool_minus);
	if (write_return[4] < 0)
		return (write_return[4]);
}
