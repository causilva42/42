/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prints_2_bonus.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/14 09:46:43 by causilva          #+#    #+#             */
/*   Updated: 2025/05/22 17:07:16 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

int	print_li(long n, t_flags flags)
{
	long	temp;
	int		bool_sign;
	int		num_len;
	int		zeros;
	int		blanks;

	if (flags.bool_zero)
		flags.point = flags.num;
	if (flags.type == 'u')
	{
		flags.bool_plus = 0;
		flags.bool_space = 0;
	}
	temp = n;
	bool_sign = (temp < 0 || flags.bool_plus || flags.bool_space);
	num_len = (temp == 0);
	while (temp)
	{
		temp /= 10;
		num_len++;
	}
	zeros = ft_biggest(0, flags.point - num_len);
	blanks = ft_biggest(0, flags.num - zeros - num_len);
	print_nblanks(blanks * (!flags.bool_minus));
	if (n < 0)
		ft_putchar_fd('-', 1);
	else if (flags.bool_plus)
		ft_putchar_fd('+', 1);
	else if (flags.bool_space)
		ft_putchar_fd(' ', 1);
	print_nzeros(zeros);
	ft_putnbr_fd(n - 2 * n * (n < 0), 1);
	print_nblanks(blanks * (flags.bool_minus));
	return (bool_sign + num_len + zeros + blanks);
}

int	print_lhex(unsigned long n, t_flags flags)
{
	unsigned long	temp;
	int				extra;
	int				num_len;
	int				zeros;
	int				blanks;

	if (flags.bool_zero)
		flags.point = flags.num;
	temp = n;
	extra = (2 * flags.bool_hashtag);
	num_len = (temp == 0);
	while (temp)
	{
		temp /= 16;
		num_len++;
	}
	zeros = ft_biggest(0, flags.point - extra - num_len);
	blanks = ft_biggest(0, flags.num - extra - zeros - num_len);
	print_nblanks(blanks * (!flags.bool_minus));
	if (flags.bool_hashtag && flags.type == 'x')
		ft_putstr_fd("0x", 1);
	else if (flags.bool_hashtag && flags.type == 'X')
		ft_putstr_fd("0X", 1);
	print_nzeros(zeros);
	putnbr_lhex(n, flags.type);
	print_nblanks(blanks * (flags.bool_minus));
	return (extra + num_len + zeros + blanks);
}

void	putnbr_lhex(unsigned long n, char c)
{
	if (n < 16)
	{
		if (n < 10)
			ft_putchar_fd(n + '0', 1);
		else
			ft_putchar_fd((n - 10 + 'A' + (32 * (c == 'x'))), 1);
	}
	else
	{
		putnbr_lhex(n / 16, c);
		putnbr_lhex(n % 16, c);
	}
}

int	print_lubase(unsigned long n, const char *base)
{
	int	base_len;
	int	write_return[2];

	base_len = ft_strlen(base);
	if (n < (unsigned long) base_len)
		return (write(1, &base[n], 1));
	write_return[0] = print_lubase(n / base_len, base);
	if (write_return[0] < 0)
		return (write_return[0]);
	write_return[1] = print_lubase(n % base_len, base);
	if (write_return[1] < 0)
		return (write_return[1]);
	return (write_return[0] + write_return[1]);
}
