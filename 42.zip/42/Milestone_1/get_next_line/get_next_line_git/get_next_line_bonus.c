/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 12:13:44 by causilva          #+#    #+#             */
/*   Updated: 2025/05/19 17:03:04 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

char	*get_next_line(int fd)
{
	static char	buffer[BUFFER_FD_LIMIT][BUFFER_SIZE + 1];
	char		*string;
	int			read_return;

	string = NULL;
	read_return = 1;
	while (!string || (!ft_strchr(string, '\n') && read_return != 0))
	{
		if (ft_strlen(buffer[fd]) == 0)
		{
			read_return = read(fd, buffer[fd], BUFFER_SIZE);
			if (read_return < 0)
				return (free(string), NULL);
			buffer[fd][read_return] = '\0';
		}
		update_string(&string, buffer[fd]);
		if (!string)
			return (NULL);
		update_buffer(buffer[fd]);
	}
	if (ft_strlen(string) == 0)
		return (free(string), NULL);
	return (string);
}

void	update_string(char **string, const char *buffer)
{
	char	*new_string;
	int		len1;
	int		len2;

	len1 = 0;
	if (*string)
		len1 = ft_strlen(*string);
	len2 = 0;
	while (buffer[len2] != '\0' && buffer[len2] != '\n')
		len2++;
	len2 += (buffer[len2] == '\n');
	new_string = malloc((len1 + len2 + 1) * sizeof(char));
	if (!new_string)
	{
		free(*string);
		*string = NULL;
		return ;
	}
	if (*string)
		ft_strlcpy(new_string, *string, len1 + 1);
	ft_strlcpy(&new_string[len1], buffer, len2 + 1);
	free(*string);
	*string = new_string;
}

void	update_buffer(char *buffer)
{
	int	i;

	i = 0;
	while (buffer[i] != '\0' && buffer[i] != '\n')
		i++;
	i += (buffer[i] == '\n');
	ft_strlcpy(buffer, &buffer[i], BUFFER_SIZE + 1 - i);
}
