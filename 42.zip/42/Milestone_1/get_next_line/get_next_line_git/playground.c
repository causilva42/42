/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   playground.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 14:15:52 by causilva          #+#    #+#             */
/*   Updated: 2025/05/12 10:44:38 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "get_next_line.h"

int	main(void)
{
	int		fd;
	char	*string;

	fd = open("teste.txt", O_RDONLY);
	string = get_next_line(fd);
	while (string)
	{
		write(1, "|", 1);
		write(1, string, ft_strlen(string));
		free(string);
		string = get_next_line(fd);
	}
	close(fd);
	return (0);
}
