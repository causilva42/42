/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 12:13:59 by causilva          #+#    #+#             */
/*   Updated: 2025/05/19 16:38:49 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include <stdlib.h>
# include <unistd.h>

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 42
# endif

//----------------------------------------------
//----------------GET_NEXT_LINE.C---------------
//----------------------------------------------
char	*get_next_line(int fd);
void	update_string(char **string, const char *buffer);
void	update_buffer(char *buffer);

//----------------------------------------------
//-------------GET_NEXT_LINE_UTILS.C------------
//----------------------------------------------
char	*ft_strchr(const char *s, int c);
size_t	ft_strlcpy(char *dst, const char *src, size_t size);
size_t	ft_strlen(const char *s);

#endif