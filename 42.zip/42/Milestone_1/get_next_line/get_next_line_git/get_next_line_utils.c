/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 13:26:07 by causilva          #+#    #+#             */
/*   Updated: 2025/05/06 12:15:12 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*ft_bufjoin(char const *string, char const *buffer, size_t n)
{
	char	*new_string;
	int		len1;

	if (!buffer)
		return (NULL);
	if (!string)
	{
		new_string = malloc((n + 1) * sizeof(char));
		if (!new_string)
			return (NULL);
		ft_strlcpy(new_string, buffer, n + 1);
	}
	else
	{
		len1 = ft_strlen(string);
		new_string = malloc((len1 + n + 1) * sizeof(char));
		if (!new_string)
			return (NULL);
		ft_strlcpy(new_string, string, len1 + 1);
		ft_strlcpy(&new_string[len1], buffer, n + 1);
	}
	return (new_string);
}

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t	i;

	if (size == 0)
		return (ft_strlen(src));
	i = 0;
	while (src[i] != '\0' && i < size - 1)
	{
		dst[i] = (char) src[i];
		i++;
	}
	dst[i] = '\0';
	return (ft_strlen(src));
}

size_t	ft_strlen(const char *s)
{
	size_t	i;

	i = 0;
	while (s[i] != '\0')
		i++;
	return (i);
}
