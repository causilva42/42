/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/05 12:13:44 by causilva          #+#    #+#             */
/*   Updated: 2025/05/12 11:33:41 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*get_next_line(int fd)
{
	char	*line;
	char	*temp;
	static char	buffer[BUFFER_SIZE];
	int		read_return;

	line = NULL;
	temp = NULL;
	//buffer = malloc(BUFFER_SIZE * sizeof(char));
	read_return = BUFFER_SIZE;
	while ((read_return == BUFFER_SIZE && read_return != 0)
		&& (!line || buffer[BUFFER_SIZE - 1] != '\n'))
	{
		read_return = ft_read_line(fd, buffer, BUFFER_SIZE);
		if (read_return < 0)
			return (free(line), free(temp), NULL);
		temp = ft_bufjoin(line, buffer, read_return);
		free(line);
		line = temp;
		if (!line || !line[0])
			return (NULL);
	}
	//free(buffer);
	return (line);
}

int	ft_read_line(int fd, char *buffer, size_t nbytes)
{
	size_t	i;
	int		read_return;

	if (!buffer)
		return (-1);
	i = 0;
	read_return = 1;
	while (read_return != 0 && i < nbytes)
	{
		read_return = read(fd, &buffer[i], 1);
		if (read_return < 0)
			return (read_return);
		if (buffer[i] == '\n')
			return (i + 1);
		i += read_return;
	}
	return (i);
}
