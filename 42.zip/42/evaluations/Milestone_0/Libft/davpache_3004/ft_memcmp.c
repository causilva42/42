/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 19:31:36 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 15:19:24 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	memcmp(const void *s1, const void *s2, size_t n)
{
	size_t			i;
	unsigned char	*s1_ref;
	unsigned char	*s2_ref;

	s1_ref = (unsigned char *) s1;
	s2_ref = (unsigned char *) s2;
	i = 0;
	while (i < n && s1_ref[i] && s2_ref[i])
		if (s1_ref[i] != s2_ref[i])
			return (s1_ref[i] - s2_ref[i]);
	return (0);
}

/* int main()
{
	int test1 = memcmp("success: string 1", "success: string 2", 28);
	int test2 = memcmp("fail: string 1", "fail: string 2", 4);
	return (1);
} */ 