/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 19:41:37 by davpache          #+#    #+#             */
/*   Updated: 2025/04/30 11:14:49 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h> */
/* #include <unistd.h> */
#include "libft.h"

char	*strnstr(const char *big, const char *little, size_t len)
{
	size_t	i;
	size_t	check;

	i = 0;
	if (!*little)
		return (NULL);
	while (big[i])
	{
		check = 0;
		while (big[check + i] == little[check] && check + i <= len)
			check++;
		if (!little[check])
			return ((char *) &big[i]);
		i++;
	}
	return (0);
}

int main()
{
	char *str = "iVE GOT THIS FEELING IM IN MOTION, \200 SUDDEN";
	printf("%s\n%s\n\n", str, strnstr(str, "MO", 824723));
}