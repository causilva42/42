/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 13:56:46 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 16:33:56 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <unistd.h>

void	ft_putnbr_fd(int n, int fd)
{
	char	out;

	if (n == -2147483648)
		write(fd, "-2147483648", 11);
	if (n == -2147483648)
		return ;
	if (n < 0)
		write(fd, "-", 1);
	if (n < 0)
		n = -n;
	if (n >= 10)
		ft_putnbr_fd(n / 10, fd);
	out = (n % 10) + '0';
	write(fd, &out, 1);
}

/* int main()
{
	ft_putnbr_fd(-2147483648, 1);
	printf("\n");
	ft_putnbr_fd(0, 1);
	printf("\n");
	ft_putnbr_fd(-1, 1);
	printf("\n");
	ft_putnbr_fd(1234567, 1);
	printf("\n");
} */