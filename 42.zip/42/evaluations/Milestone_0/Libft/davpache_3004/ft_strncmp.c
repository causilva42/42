/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 18:52:26 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 17:39:46 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h>
#include <string.h> */
#include "libft.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int	ft_strncmp(const char *s1, const char *s2, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n && s1[i] && s2[i])
	{
		if (s1[i] != s2[i])
			break ;
		i++;
	}
	return ((unsigned char) s1[i] - (unsigned char)s2[i]);
}

/* int main(void)
{
	char s1[] = "test\200";
	char s2[] = "test\0";
	size_t n = 6;
	printf("%d\n%d\n", 
	ft_strncmp(s1, s2, n), strncmp(s1, s2, n));
	return (0);	
} */