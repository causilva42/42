/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 13:57:34 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 14:21:19 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "libft.h"
/* #include "ft_memset.c" */

void	ft_bzero(void *s, size_t n)
{
	ft_memset(s, '\0', n);
}

/* int main()
{
	char	*ptr;
	ptr = malloc(16);
	ft_bzero(ptr, 8);
	return (0);
} */