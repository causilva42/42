/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 23:18:56 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 17:18:37 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "libft.h"
/* #include "ft_strlen.c" */
/* #include "ft_strdup.c" */

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*out;
	int		i;

	i = 0;
	if (!s)
		return (NULL);
	if (start > ft_strlen(s))
		return (ft_strdup(""));
	if (ft_strlen(s + start) < len)
		len = ft_strlen(s + start);
	out = (char *) malloc(len * sizeof(char));
	if (!out)
		return (NULL);
	while (i < (int) len)
	{
		out[i] = s[i + start];
		i++;
	}
	return (out);
}

/* int main()
{
	char haystack[] = "you must hide the needle and all that follows!";
	printf("%s\n", ft_substr(haystack, 0, 14));
	printf("%s\n", ft_substr(haystack, 14, 47));
} */