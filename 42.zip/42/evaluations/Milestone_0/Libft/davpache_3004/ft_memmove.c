/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 17:53:59 by davpache          #+#    #+#             */
/*   Updated: 2025/04/22 19:34:36 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	char		*tmp;
	size_t		i;
	const char	*src_ref;
	char		*dest_ref;

	tmp = malloc(n * sizeof(char));
	src_ref = (const char *) src;
	dest_ref = (char *) dest;
	i = -1;
	while (++i <= n)
		tmp[i] = (char) src_ref[i];
	i = -1;
	while (++i <= n)
		dest_ref[i] = tmp[i];
	return (dest);
}

/* int main()
{
	char *ptr1 = "";
	char *ptr2 = malloc(14 * sizeof(char));
	ft_memmove(ptr2, ptr1, 14);
	return (0);
} */