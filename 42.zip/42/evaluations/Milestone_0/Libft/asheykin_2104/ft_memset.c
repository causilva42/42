/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 17:14:02 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/15 19:52:22 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Copies 'c' (an unsigned char) to the first 'n' bytes of the 
 * memory area pointed to, by the argument 'dest''.
 *
 * @param ptr Pointer to the memory area to be filled.
 * @param c Value to set. The value is passed as an int, 
 * but the function treats it as an unsigned char.
 * @param n Number of bytes to fill.
 * @return A pointer to the memory area 'dest'.
 */
void	*ft_memset(void *dest, int c, size_t n)
{
	size_t			i;
	unsigned char	*str;

	i = 0;
	str = (unsigned char *)dest;
	while (i < n)
	{
		str[i++] = c;
	}
	return (dest);
}
