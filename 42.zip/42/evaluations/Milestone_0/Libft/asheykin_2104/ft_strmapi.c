/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/11 14:53:15 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/21 10:04:27 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Applies a function to each character of a string, 
 * creating a new string.
 *
 * Iterates over the string 's', passing the index of each character and the 
 * character itself to the function 'f'. A new string is created from the results
 * of successive applications of 'f'. The new string is allocated using malloc.
 * If the allocation fails, NULL is returned.
 *
 * @param s The string to iterate over.
 * @param f The function to apply to each character of the string. The function 
 *          takes two arguments: the index of the character and the character 
 *          itself, and it returns a modified character.
 * 
 * @return A new string created by applying 'f' to each character of 's', or 
 *         NULL if the allocation fails.
 */
char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	int		s_len;
	char	*output;
	int		i;

	if (s == NULL)
		return (NULL);
	if (f == NULL)
		return (ft_strdup(s));
	s_len = ft_strlen(s);
	output = (char *)malloc((s_len + 1) * sizeof(char));
	if (output == NULL)
		return (NULL);
	i = 0;
	while (i < s_len)
	{
		output[i] = f(i, s[i]);
		i++;
	}
	output[i] = '\0';
	return (output);
}
