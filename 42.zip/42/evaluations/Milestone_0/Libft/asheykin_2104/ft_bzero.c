/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 21:56:56 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/15 19:54:02 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Place 'n' zero-valued bytes in the area pointed to by 's'.
 * @param s A pointer to the memory area to be zeroed.
 * @param n Number of bytes to be zeroed.
 */
void	ft_bzero(void *s, size_t n)
{
	ft_memset(s, '\0', n);
}
