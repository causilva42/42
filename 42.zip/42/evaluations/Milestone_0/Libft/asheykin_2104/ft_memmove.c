/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/09 10:19:53 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 15:24:51 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Copies 'n' bytes from memory area 'src' to memory area 'dest', 
 * handling overlapping memory regions.
 *
 * @param dest Pointer to the destination buffer.
 * @param src Pointer to the source buffer.
 * @param n Number of bytes to copy.
 * @return A pointer to 'dest'.
 */
void	*ft_memmove(void *dest, const void *src, size_t n)
{
	unsigned char	*dest_str;
	unsigned char	*src_str;

	if (dest == src || n == 0)
		return (dest);
	dest_str = (unsigned char *)dest;
	src_str = (unsigned char *)src;
	if (dest <= src)
	{
		while (n--)
		{
			*dest_str++ = *src_str++;
		}
	}
	else
	{
		dest_str += n - 1;
		src_str += n - 1;
		while (n--)
		{
			*dest_str-- = *src_str--;
		}
	}
	return (dest);
}
