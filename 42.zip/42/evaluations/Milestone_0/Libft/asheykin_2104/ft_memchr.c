/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 13:02:29 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/15 21:10:05 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Searches for the first occurrence of the character 'c' (unsigned char)
 * in the first 'n' bytes of the memory clock pointed to, by 'str'.
 *
 * @param str Pointer to the memory block where the search is performed.
 * @param c Byte value to search for (interpreted as an unsigned char).
 * @param n Number of bytes to search.
 * @return Pointer to the matching byte, or NULL if the byte is not found.
 */
void	*ft_memchr(const void *str, int c, size_t n)
{
	size_t			i;
	unsigned char	*str_c;

	i = 0;
	str_c = (unsigned char *)str;
	while (i < n)
	{
		if (str_c[i] == (unsigned char)c)
			return (str_c + i);
		i++;
	}
	return (NULL);
}
