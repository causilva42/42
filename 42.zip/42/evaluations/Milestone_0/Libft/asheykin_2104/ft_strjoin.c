/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 19:31:42 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 12:20:51 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Concatenates two strings into a newly allocated string.
 *
 * Allocates memory and returns a new string that is the result of 
 * concatenating 's1' followed by 's2'.
 *
 * @param s1 The prefix string.
 * @param s2 The suffix string.
 * @return A pointer to the newly created string, 
 * or NULL if the allocation fails.
 */
char	*ft_strjoin(char const *s1, char const *s2)
{
	int		total_len;
	char	*s3;

	if (s1 == NULL && s2 == NULL)
		return (NULL);
	if (s1 == NULL)
		return (ft_strdup(s2));
	if (s2 == NULL)
		return (ft_strdup(s1));
	total_len = ft_strlen(s1) + ft_strlen(s2);
	s3 = (char *)malloc((total_len + 1) * sizeof(char));
	if (s3 == NULL)
		return (NULL);
	ft_strlcpy(s3, s1, total_len + 1);
	ft_strlcat(s3, s2, total_len + 1);
	return (s3);
}
