/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/12 16:13:20 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 09:10:17 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Allocates memory and returns a new node.
 *
 * This function creates a new node, initializes its `content` with the given
 * parameter, and sets its `next` pointer to NULL.
 *
 * @param content The content to store in the new node.
 * @return A pointer to the new node.
 * @note The `next` pointer of the new node is initialized to NULL.
 */
t_list	*ft_lstnew(void *content)
{
	t_list	*new;

	new = (t_list *)malloc(sizeof(t_list));
	if (new)
	{
		new->content = content;
		new->next = NULL;
	}
	return (new);
}
