/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 16:48:21 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 12:40:59 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Converts a lowercase letter to uppercase.
 *
 * @param c The character to be converted to uppercase.
 * 
 * @return The uppercase equivalent of 'c' if 'c' is lowercase, 
 * otherwise 'c' itself.
 */
int	ft_toupper(int arg)
{
	if (arg >= 'a' && arg <= 'z')
		arg -= 32;
	return (arg);
}
