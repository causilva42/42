/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 16:53:06 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 12:40:05 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Converts an uppercase letter to lowercase.
 *
 * @param c The character to be converted to lowercase.
 * 
 * @return The lowercase equivalent of 'c' if 'c' is uppercase, 
 * otherwise 'c' itself.
 */
int	ft_tolower(int arg)
{
	if (arg >= 'A' && arg <= 'Z')
		arg += 32;
	return (arg);
}
