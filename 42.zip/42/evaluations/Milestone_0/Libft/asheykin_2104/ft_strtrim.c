/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 20:06:43 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/21 10:06:01 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_char_in_set(char c, char const *set)
{
	int	i;

	i = 0;
	while (set[i] != '\0')
	{
		if (c == set[i])
			return (1);
		i++;
	}
	return (0);
}

/**
 * @brief Trims the characters from the beginning and end of a string.
 *
 * Allocates memory and returns a new string that is a copy of 's1' with all 
 * characters from 'set' removed from both the start and the end of the string.
 *
 * @param s1 The string to be trimmed.
 * @param set The set of characters to remove from the beginning and the end 
 * of 's1'.
 * 
 * @return A new string with characters from 'set' removed, 
 * or NULL if memory allocation fails.
 */
char	*ft_strtrim(char const *s1, char const *set)
{
	int		i;
	int		j;
	int		k;
	char	*trimmed;

	if (s1 == NULL)
		return (NULL);
	if (set == NULL)
		return (ft_strdup(s1));
	i = 0;
	while (s1[i] != '\0' && ft_char_in_set(s1[i], set))
		i++;
	j = ft_strlen(s1);
	while (j > i && ft_char_in_set(s1[j - 1], set))
		j--;
	trimmed = (char *)malloc((j - i + 1) * sizeof(char));
	if (trimmed == NULL)
		return (NULL);
	k = 0;
	while (i < j)
		trimmed[k++] = s1[i++];
	trimmed[k] = '\0';
	return (trimmed);
}
