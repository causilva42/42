/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 11:35:41 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/15 21:04:46 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Locates the first occurrence of a character in a string.
 *
 * Searches for the first occurrence of the character 'c' in the string 's'.
 * The terminating null byte is considered part of the string, so if 'c' is '\0',
 * the function will locate it as well.
 *
 * @param s The string to search.
 * @param c The character to find.
 * @return A pointer to the first occurrence of the character in the string,
 *         or NULL if the character is not found.
 */
char	*ft_strchr(const char *str, int c)
{
	int	i;
	int	str_len;

	i = 0;
	str_len = ft_strlen(str);
	while (i <= str_len)
	{
		if (str[i] == (char)c)
			return ((char *)(str + i));
		i++;
	}
	return (NULL);
}
