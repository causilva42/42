/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/11 09:36:25 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 11:29:50 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_length(long n)
{
	int	length;

	length = (n <= 0);
	while (n)
	{
		n /= 10;
		length++;
	}
	return (length);
}

/**
 * @brief Converts a an integer into a string.
 * @param n Integer to convert.
 * @return String.
 */
char	*ft_itoa(int n)
{
	long	n_long;
	int		length;
	char	*str;

	n_long = (long)n;
	length = ft_length(n);
	str = (char *)malloc((length + 1) * sizeof(char));
	if (str == NULL)
		return (NULL);
	str[length] = '\0';
	if (n_long < 0)
	{
		str[0] = '-';
		n_long = -n_long;
	}
	else if (n_long == 0)
		str[0] = '0';
	while (n_long > 0)
	{
		str[--length] = (n_long % 10) + '0';
		n_long /= 10;
	}
	return (str);
}
