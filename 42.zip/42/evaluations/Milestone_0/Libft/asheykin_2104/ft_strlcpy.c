/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 09:22:25 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 12:23:57 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Copies a string into a destination buffer with size checking.
 *
 * Copies up to 'size - 1' characters from the string 'src' to 'dst',
 * null-terminating the result if 'size' is not 0.
 *
 * @param dst The destination buffer.
 * @param src The source string to copy from.
 * @param size The size of the destination buffer.
 * @return The total length of the string it tried to copy (length of 'src').
 *         If the return value is >= size, truncation occurred.
 */
size_t	ft_strlcpy(char *dest, const char *src, size_t size)
{
	size_t	i;

	if (size > 0)
	{
		i = 0;
		while (i < size - 1 && src[i] != '\0')
		{
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
	}
	return (ft_strlen(src));
}
