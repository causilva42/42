/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 15:03:39 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 12:33:24 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Locates the first occurrence of a substring within a string up to a 
 * specified length.
 *
 * @param s1 The string to search in.
 * @param s2 The substring to search for.
 * @param n The maximum number of characters to search through in 's1'.
 * 
 * @return A pointer to the beginning of the located substring, 
 * or NULL if not found. If 's2' is empty, returns pointer to 's1'.
 */
char	*ft_strnstr(const char *s1, const char *s2, size_t n)
{
	size_t	i;
	size_t	s2_len;

	if (s2[0] == '\0')
		return ((char *)s1);
	i = 0;
	s2_len = ft_strlen(s2);
	while (s1[i] != '\0' && i + s2_len <= n)
	{
		if (ft_strncmp(s1 + i, s2, s2_len) == 0)
			return ((char *)s1 + i);
		i++;
	}
	return (NULL);
}
