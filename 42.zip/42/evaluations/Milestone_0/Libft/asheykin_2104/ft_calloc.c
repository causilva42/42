/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 16:55:44 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 14:31:11 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Allocates memory and initializes it to zero.
 *
 * Allocates memory for `n` elements of `size` bytes each and
 * returns a pointer to the allocated memory. The memory is set to zero.
 *
 * @param n    Number of elements to allocate.
 * @param size Size of each element.
 * @return     A pointer to the allocated and zero-initialized memory,
 *             or NULL if the allocation fails.
 */
void	*ft_calloc(size_t nitems, size_t size)
{
	void	*mem;

	if (nitems * size > SIZE_MAX)
		return (NULL);
	mem = malloc(nitems * size);
	if (mem != NULL)
		ft_bzero(mem, nitems * size);
	return (mem);
}
