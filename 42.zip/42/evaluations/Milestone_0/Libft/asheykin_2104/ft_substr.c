/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 17:40:26 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 15:47:30 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Creates a substring from a given string.
 *
 * Allocates memory and returns a new string that is a substring of 's'.
 * The substring starts at index 'start' and has a maximum length of 'len'.
 * If 'start' is beyond the end of the string, the function returns an 
 * empty string. If the allocation fails, it returns NULL.
 *
 * @param s The original string from which to create the substring.
 * @param start The starting index of the substring within 's'.
 * @param len The maximum length of the substring.
 * 
 * @return A new string that is the substring, 
 * or NULL if memory allocation fails.
 */
char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*substr;

	if (s == NULL)
		return (NULL);
	if (start > ft_strlen(s))
		return (ft_strdup(""));
	if ((unsigned int)len > ft_strlen(s) - start)
		len = ft_strlen(s) - start;
	substr = (char *)malloc((len + 1) * sizeof(char));
	if (substr == NULL)
		return (NULL);
	ft_strlcpy(substr, s + start, len + 1);
	return (substr);
}
