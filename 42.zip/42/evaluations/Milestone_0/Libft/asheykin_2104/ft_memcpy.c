/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 22:10:52 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 13:06:21 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Copies 'n' bytes from memory area 'src' to memory area 'dest'.
 * The memory areas must not overlap. If they do, use ft_memmove() instead.
 * 
 * @param dest Pointer to the destination buffer.
 * @param src Pointer to the source buffer.
 * @param n Number of bytes to copy.
 * @return A pointer to 'dest'.
 */
void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	size_t	i;

	i = 0;
	while (i < n)
	{
		((unsigned char *)dest)[i] = ((unsigned char *)src)[i];
		i++;
	}
	return (dest);
}
