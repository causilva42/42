/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 14:50:05 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 11:49:22 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Compares the first 'n' bytes of the memory areas 'str1' and 'str2'.
 * The comparison is done using unsigned characters.
 *
 * @param str1 Pointer to the first memory area.
 * @param str2 Pointer to the second memory area.
 * @param n Number of bytes to compare.
 * @return If the return value < 0, it indicates str1 is less than str2.
 * If the return value > 0, it indicates str2 is less than str1.
 * If the return value == 0, it represents str1 is equivalent to str2.
 */
int	ft_memcmp(const void *str1, const void *str2, size_t n)
{
	size_t			i;
	unsigned char	*str1_c;
	unsigned char	*str2_c;

	i = 0;
	str1_c = (unsigned char *)str1;
	str2_c = (unsigned char *)str2;
	while (i < n)
	{
		if (str1_c[i] != str2_c[i])
			return (str1_c[i] - str2_c[i]);
		i++;
	}
	return (0);
}
