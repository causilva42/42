/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 16:37:39 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 13:03:40 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

static int	ft_isspace(const char c)
{
	if (c == ' ' || c == '\t' || c == '\r'
		|| c == '\n' || c == '\v' || c == '\f')
		return (1);
	return (0);
}

static int	ft_issign(const char c)
{
	if (c == '-')
		return (-1);
	if (c == '+')
		return (1);
	return (0);
}

static int	ft_isbase10(const char c)
{
	if (c >= '0' && c <= '9')
		return (c - '0');
	return (-1);
}

/**
 * @brief Converts a string to an integer.
 * @param str A pointer to the null-terminated string to convert.
 * @return The converted integer value.
 */
int	ft_atoi(const char *str)
{
	int	i;
	int	res;
	int	sign;

	i = 0;
	res = 0;
	sign = 1;
	while (ft_isspace(str[i]))
		i++;
	if (ft_issign(str[i]))
	{
		sign = sign * ft_issign(str[i]);
		i++;
	}
	while (ft_isbase10(str[i]) >= 0)
	{
		res = res * 10 + ft_isbase10(str[i]);
		i++;
	}
	return (sign * res);
}
