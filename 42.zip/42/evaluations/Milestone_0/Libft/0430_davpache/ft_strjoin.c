/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 09:00:27 by davpache          #+#    #+#             */
/*   Updated: 2025/04/24 22:39:54 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>
#include <stdlib.h>

char	*ft_strjoin(char const *s1, char const *s2)
{
	char	*out;
	size_t	s1_size;
	size_t	s2_size;

	if (s1 == NULL || s2 == NULL)
		return (NULL);
	s1_size = ft_strlen(s1);
	s2_size = ft_strlen(s2);
	out = malloc(sizeof(char) * (s1_size + s2_size));
	if (!out)
		return (NULL);
	ft_strlcat(out, s1, s1_size);
	ft_strlcat(out, s2, s2_size);
	return (out);
}

/* int main()
{
	printf("%s\n", ft_strjoin("fetch me ", "their souls!"));
} */
