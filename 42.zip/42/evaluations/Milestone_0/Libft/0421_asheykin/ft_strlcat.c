/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 09:40:57 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/21 11:37:58 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Appends the source string to the destination string 
 * with size checking.
 *
 * Appends string 'src' to the end of 'dest'. It will append at most 
 * 'size - strlen(dest) - 1' bytes, null-terminating the result.
 *
 * @param dest The destination buffer.
 * @param src The source string to append.
 * @param size The total size of the destination buffer.
 * @return The total length of the string it tried to create:
 *         the initial length of 'dest' plus the length of 'src'.
 *         If the return value is >= size, the output string has been truncated.
 */
size_t	ft_strlcat(char *dest, const char *src, size_t size)
{
	size_t	i;
	size_t	j;

	i = 0;
	j = 0;
	while (dest[i] != '\0' && i < size)
		i++;
	while ((i + j + 1) < size && src[j] != '\0')
	{
		dest[i + j] = src[j];
		j++;
	}
	if (i < size)
		dest[i + j] = '\0';
	return (i + ft_strlen(src));
}

#include <stdio.h>
#include <string.h>
#include <bsd/string.h>
int	test_ft_strlcat()
{
	char	dst[20];
	char	dst2[20];

	dst[0] = '\0';
	dst2[0] = '\0';
	ft_strlcat(dst, "123", -1);
	strlcat(dst2, "123", -1);
	if (strcmp(dst, dst2) != 0)
		return (1);
	ft_strlcat(dst, "123", 0);
	strlcat(dst2, "123", 0);
	if (strcmp(dst, dst2) != 0)
		return (2);
	ft_strlcat(dst, "123", 2);
	strlcat(dst2, "123", 2);
	if (strcmp(dst, dst2) != 0)
		return (3);
	ft_strlcat(dst, "123", 1);
	strlcat(dst2, "123", 1);
	if (strcmp(dst, dst2) != 0)
		return (4);
	ft_strlcat(dst, "", 4);
	strlcat(dst2, "", 4);
	if (strcmp(dst, dst2) != 0)
		return (5);
	ft_strlcat(dst, "123", 9);
	strlcat(dst2, "123", 9);
	if (strcmp(dst, dst2) != 0)
		return (6);
	return (0);
}
int	main(void)
{
	if (test_ft_strlcat() == 0)
		printf("OK");
	else
		printf("!KO!");
	printf("\n");
}
