/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 10:10:32 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 11:25:15 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Checks if a character is a letter.
 *
 * @param c The character to check.
 * @return  1 if the character is a letter, 0 otherwise.
 */
int	ft_isalpha(int arg)
{
	return ((arg >= 'A' && arg <= 'Z') || (arg >= 'a' && arg <= 'z'));
}
