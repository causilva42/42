/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vibarre <vibarre@student.42lisboa.com      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 12:12:05 by vibarre           #+#    #+#             */
/*   Updated: 2025/05/03 12:12:06 by vibarre          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	_putnbr(long n, int fd)
{
	int	i;

	i = 0;
	if (n > 9)
		i += _putnbr((n / 10), fd);
	ft_putchar_fd((n % 10 + '0'), fd);
	return (i + 1);
}

int	ft_putnbr_fd(int n, int fd)
{
	long	new;
	int		i;

	new = n;
	i = 0;
	if (new < 0)
	{
		ft_putchar_fd('-', fd);
		new = -new;
		i++;
	}
	return (i + _putnbr(new, fd));
}
