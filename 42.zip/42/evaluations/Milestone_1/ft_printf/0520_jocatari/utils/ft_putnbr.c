/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/19 11:29:31 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 16:33:34 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Writes an integer to the specified file descriptor in a given base.
 *
 * This function writes the integer @p n to the file descriptor @p fd, 
 * using the specified @p base_digits. It handles negative numbers and validates 
 * the file descriptor.
 *
 * @param n The integer to be written.
 * @param base_digits The string of digits representing the base (e.g.,
 * "0123456789" for decimal).
 * @param fd The file descriptor to write to.
 * @return The total number of characters written or -1 if @p fd is invalid.
 * 
 * @note Internal functions: `ft_strlen`. External functions: `write`.
 * @par Use case: Emitting numeric values in various bases (e.g., decimal, hex) 
 * to any FD — useful for logging counters, debugging values,
 * or formatting outputs.
 */

#include "utils.h"

ssize_t	ft_putnbr(int n, char *base_digits, int fd)
{
	ssize_t		count;
	int long	num;
	int			isneg;
	char		s[21];

	if (fd < 0)
		return (-1);
	isneg = 0;
	num = n;
	if (num < 0)
	{
		isneg = 1;
		num = -num;
	}
	ft_bzero(s, 21);
	process_nbr(num, isneg, s, base_digits);
	count = write(fd, s, ft_strlen(s));
	return (count);
}
