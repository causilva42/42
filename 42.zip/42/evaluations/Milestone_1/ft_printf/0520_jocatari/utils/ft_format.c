/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_format.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/06 09:52:27 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 16:07:11 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Orchestrates format specifier processing for ft_printf.
 *
 * This function processes the format specifier at @p str[*i + 1], retrieves 
 * the corresponding value from @p args, and writes it to STDOUT_FILENO.
 * It increments @p i to skip the specifier and returns the number of characters
 * written.
 *
 * @param str The format string containing the specifier.
 * @param i Pointer to the current index in @p str.
 * @param args Pointer to the variable argument list.
 * @return The number of characters written, or -1 on error.
 *
 * @note Internal functions: `ft_putchar`, `ft_putstr`, `ft_putptr`,
 * `ft_putnbr`.
 * @par Use case: Called by ft_printf to handle individual format specifiers 
 * (e.g., %c, %s, %p) and their corresponding argument output.
 */

#include "utils.h"

ssize_t	ft_format(const char *str, size_t *i, va_list *args)
{
	ssize_t	count;
	char	c;

	count = 0;
	if (str[*i + 1] == 'c')
	{
		c = va_arg(*args, int);
		count = write(STDOUT_FILENO, &c, 1);
	}
	else if (str[*i + 1] == 's')
		count = ft_putstr(va_arg(*args, char *), STDOUT_FILENO);
	else if (str[*i + 1] == 'p')
		count = ft_putptr(va_arg(*args, void *), B16, STDOUT_FILENO);
	else if (str[*i + 1] == 'd' || str[*i + 1] == 'i')
		count = ft_putnbr(va_arg(*args, int), B10, STDOUT_FILENO);
	else if (str[*i + 1] == 'u')
		count = ft_putunbr(va_arg(*args, unsigned int), B10, STDOUT_FILENO);
	else if (str[*i + 1] == 'x')
		count = ft_putunbr(va_arg(*args, unsigned int), B16, STDOUT_FILENO);
	else if (str[*i + 1] == 'X')
		count = ft_putunbr(va_arg(*args, unsigned int), B16U, STDOUT_FILENO);
	else if (str[*i + 1] == '%')
		count = write(STDOUT_FILENO, "%", 1);
	*i += 2;
	return (count);
}
