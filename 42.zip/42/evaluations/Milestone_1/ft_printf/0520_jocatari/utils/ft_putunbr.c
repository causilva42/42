/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putunbr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/19 11:29:31 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 16:35:53 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Writes an integer to the specified file descriptor in a given base.
 *
 * This function writes the integer @p n to the file descriptor @p fd, 
 * using the specified @p base_digits. It handles negative numbers and validates 
 * the file descriptor.
 *
 * @param n The integer to be written.
 * @param base_digits The string of digits representing the base (e.g.,
 * "0123456789" for decimal).
 * @param fd The file descriptor to write to.
 * @return The total number of characters written or -1 if @p fd is invalid.
 * 
 * @note Internal functions: `ft_strlen`. External functions: `write`.
 * @par Use case: Emitting numeric values in various bases (e.g., decimal, hex) 
 * to any FD — useful for logging counters, debugging values,
 * or formatting outputs.
 */

#include "utils.h"

ssize_t	ft_putunbr(size_t n, char *base_digits, int fd)
{
	ssize_t	count;
	char	s[12];

	if (fd < 0)
		return (-1);
	ft_bzero(s, 12);
	process_nbr(n, 0, s, base_digits);
	count = write(fd, s, ft_strlen(s));
	return (count);
}
