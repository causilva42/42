/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/29 20:20:39 by asheykin          #+#    #+#             */
/*   Updated: 2025/05/12 11:14:55 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char	*extract_line(char *stash)
{
	char	*line;
	int		idx;

	idx = 0;
	while (stash[idx] && stash[idx] != '\n')
		idx++;
	if (stash[idx] == '\n')
		idx++;
	line = malloc((idx + 1) * sizeof(char));
	if (!line)
		return (NULL);
	line[idx] = '\0';
	while (idx--)
		line[idx] = stash[idx];
	return (line);
}

static char	*update_stash(char *stash)
{
	char	*new_stash;
	int		idx;

	idx = 0;
	while (stash[idx] && stash[idx] != '\n')
		idx++;
	if (stash[idx] != '\n')
	{
		free(stash);
		return (NULL);
	}
	new_stash = ft_strdup(stash + idx + 1);
	free(stash);
	return (new_stash);
}

static char	*fill_stash(int fd, char *stash)
{
	char		*buffer;
	int			bytes_read;
	char		*tmp;

	buffer = malloc(BUFFER_SIZE + 1);
	if (!buffer)
		return (NULL);
	bytes_read = 1;
	while (!ft_strchr(stash, '\n') && bytes_read > 0)
	{
		bytes_read = read(fd, buffer, BUFFER_SIZE);
		if (bytes_read < 0)
		{
			free(buffer);
			return (NULL);
		}
		buffer[bytes_read] = '\0';
		tmp = ft_strjoin(stash, buffer);
		free(stash);
		stash = tmp;
	}
	free(buffer);
	return (stash);
}

char	*get_next_line(int fd)
{
	static char	stash[BUFFER_SIZE + 1];
	char		*line;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	stash = fill_stash(fd, stash);
	if (!stash)
		return (NULL);
	if (stash[0] == '\0')
	{
		free(stash);
		stash = NULL;
		return (NULL);
	}
	line = extract_line(stash);
	stash = update_stash(stash);
	return (line);
}
