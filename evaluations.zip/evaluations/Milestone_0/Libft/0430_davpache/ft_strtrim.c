/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 09:10:01 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 17:30:38 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdint.h>
#include <stdlib.h>
#include "libft.h"
#include "ft_strlen.c"

/* don't you lecture me with your... */

static int	thirty_dollar_haircut(char *in, char *set, char *buf);
static int	trim_start(char *in, char *set);
static int	trim_end(char *in, char *set);

char	*ft_strtrim(char const *s1, char const *set)
{
	int		i;
	char	*buf;
	char	*out;

	buf = malloc(sizeof(char) * ft_strlen(s1));
	if (!buf)
		return (NULL);
	out = malloc(sizeof(char)
			* thirty_dollar_haircut((char *) s1, (char *) set, buf));
	if (!out)
		return (NULL);
	i = 0;
	while (buf[i])
	{
		out[i] = buf[i];
		i++;
	}
	return (out);
}

static int	thirty_dollar_haircut(char *in, char *set, char *buf)
{
	int		i;
	int		start;
	int		end;

	start = trim_start(in, set);
	end = trim_end(in, set);
	i = 0;
	while (i + start < end)
	{
		buf[i] = in[i + start];
		i++;
	}
	return (i);
}

static int	trim_start(char *in, char *set)
{
	int	i;
	int	j;
	int	chk;

	i = -1;
	while (in[++i])
	{
		j = -1;
		while (set[++j])
		{
			chk = 0;
			if (in[i] == set[j])
			{
				chk++;
				break ;
			}
		}
		if (!chk)
			return (i++);
	}
	return (i);
}

static int	trim_end(char *in, char *set)
{
	int	i;
	int	j;
	int	chk;

	i = ft_strlen(in);
	while (in[--i])
	{
		j = -1;
		while (set[++j])
		{
			chk = 0;
			if (in[i] == set[j])
			{
				chk++;
				break ;
			}
		}
		if (!chk)
			break ;
	}
	return ((i + 1) | 0);
}

int main(void)
{
		const char str[] = "AABRACADABRAA";
		printf("%s\n", ft_strtrim(str, "A"));
		printf("%s\n", ft_strtrim(str, "x"));
		printf("%s\n", ft_strtrim(str, "ABR"));
		printf("%s\n", ft_strtrim(str, "DRABC"));
		return (0);
}