/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 12:12:55 by davpache          #+#    #+#             */
/*   Updated: 2025/04/22 15:16:30 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* #include <stdio.h> */
#include <stdlib.h>

static int	getsize(int n)
{
	int	i;

	i = 0;
	if (n < 0)
		n *= -1;
	while (n)
	{
		n /= 10;
		i++;
	}
	return (i);
}

char	*ft_itoa(int n)
{
	char	*out;
	int		i;
	int		neg;

	neg = 0 + (n < 0);
	i = getsize(n);
	out = malloc(sizeof(char) * getsize(n) + neg);
	if (!out)
		return (NULL);
	if (n < 0)
		out[0] = '-';
	if (n < 0)
		n *= -1;
	while (n && i >= neg)
	{
		out[--i + neg] = '0' + (n % 10);
		n /= 10;
	}
	return (out);
}

/* int main()
{
	printf("%s\n", ft_itoa(127));
	printf("%s\n", ft_itoa(-127));
} */