/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 19:01:06 by davpache          #+#    #+#             */
/*   Updated: 2025/04/30 10:57:49 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void	*memchr(const void *s, int c, size_t n)
{
	size_t	i;
	char	*mem;
	char	*out;

	i = 0;
	out = NULL;
	mem = (char *) s;
	while (mem[i] && i < n)
	{
		if (mem[i] == c)
			out = &mem[i];
		i++;
	}
	return (out);
}

/* int	main()
{
	void	*ptr = memchr("you will find Z in this string!", 'Z', 23);
	void	*ptr2 = memchr("you won't find Z in this string!", 'Z', 6);
	void	*ptr3 = memchr(0, 'Z', 6);
	return (0);
}
 */