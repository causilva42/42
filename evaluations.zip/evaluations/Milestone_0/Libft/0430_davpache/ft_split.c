/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/16 11:46:54 by davpache          #+#    #+#             */
/*   Updated: 2025/04/29 16:13:39 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include "libft.h"

static void	*free_all(t_split *data)
{
	int	i;

	i = 0;
	while (i < data->i)
		free(data->array[i++]);
	free(data->array);
	return (NULL);
}

static int	count_words(char const *s, char c)
{
	int		wcount;
	char	*ref;

	wcount = 0;
	ref = (char *) s;
	while (*ref++)
	{
		if (*ref - 1 != c && (*ref == c || !*ref))
			wcount++;
	}
	return (wcount);
}

static int	alloc_all(t_split *data, char const *s, char c)
{
	int		size;
	int		str;
	char	*ref;

	data->array = malloc((count_words(s, c)) * sizeof(char *));
	if (!data->array)
		return (*(int *) free_all(data) * 0);
	ref = (char *) s;
	str = 0;
	while (*ref)
	{
		size = 0;
		while (*ref++ != c && *ref)
			size++;
		data->array[str] = malloc(size * sizeof(char));
		if (!data->array[str++])
			return (*(int *) free_all(data) * 0);
		while (*ref == c && *ref)
			ref++;
	}
	data->array[str] = malloc(size * sizeof(char));
	return (1);
}

char	**ft_split(char const *s, char c)
{
	t_split	data;

	if (!alloc_all(&data, s, c) || s == NULL)
		return (NULL);
	data.j = 0;
	data.i = 0;
	data.ref = (char *) s;
	while (*data.ref)
	{
		if (*data.ref == c)
			data.j = 0;
		if (*data.ref == c && data.ref != s)
			data.i++;
		while (*data.ref == c && *data.ref)
			data.ref++;
		data.array[data.i][data.j] = *data.ref;
		data.j++;
		if (*data.ref != data.array[data.i][data.j])
			data.array[data.i][data.j] = 0;
		data.ref++;
	}
	data.array[++data.i] = NULL;
	return (data.array);
}

/* int main()
{
	ft_split("Hello! My name is Mal! How are you? :)", ' ');
}
 */