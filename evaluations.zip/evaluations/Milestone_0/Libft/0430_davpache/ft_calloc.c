/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 22:19:44 by davpache          #+#    #+#             */
/*   Updated: 2025/04/30 11:18:29 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "libft.h"

/* 
 * (nmemb * size) == 0 protection removed
 * due to differing outputs when
 * testing with stdlib calloc
 */

void	*ft_calloc(size_t nmemb, size_t size)
{
	void		*ptr;
	char		*ref;
	size_t		i;

	if (nmemb > SIZE_T_MAX / size)
		return (NULL);
	i = 0;
	ptr = malloc(nmemb * size);
	ref = ptr;
	while (i < nmemb)
		ref[i++] = 0;
	return (ptr);
}

int	main()
{
	char *ptr1 = calloc(0, 0);
	char *ptr2 = ft_calloc(0, 0);
	(void) ptr1;
	(void) ptr2;
}