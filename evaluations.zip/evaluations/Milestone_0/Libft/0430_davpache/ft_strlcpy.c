/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: davpache <davpache@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/14 18:31:49 by davpache          #+#    #+#             */
/*   Updated: 2025/04/22 21:01:15 by davpache         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>
/* 
#include <stdio.h>
#include <string.h>
#include <unistd.h>
 */

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t	i;

	i = 0;
	if (!size)
		return (ft_strlen(src));
	while (i < size - 1 && src[i])
	{
		dst[i] = src[i];
		i++;
	}
	dst[i] = '\0';
	while (src[i] != '\0')
		i++;
	return (size);
}

/* int	main()
{
	char *test = calloc(150, sizeof(char));
	char *myconst = "there's a still tension in the swell...\n";
	ft_strlcpy(test, myconst, strlen(myconst));
	printf("%s", test);
}
 */