/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/11 15:06:37 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 15:34:23 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Applies a function to each character of a string with its index.
 *
 * Applies the function 'f' to each character of the string 's', 
 * passing the index of each character and a pointer to the character itself.
 * This allows 'f' to modify the characters of the string in-place.
 *
 * @param s The string to iterate over.
 * @param f The function to apply to each character, receiving the index 
 * and a pointer to the character.
 */
void	ft_striteri(char *s, void (*f)(unsigned int, char*))
{
	int	i;

	if (s == NULL || f == NULL)
		return ;
	i = 0;
	while (s[i] != '\0')
	{
		f(i, s + i);
		i++;
	}
}
