/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 16:18:55 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 11:28:29 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Checks if a character is printable.
 *
 * @param c The character to check.
 * @return  1 if the character is printable, 0 otherwise.
 */
int	ft_isprint(int arg)
{
	return (arg >= 32 && arg < 127);
}
