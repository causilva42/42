/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 15:53:41 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 11:27:02 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Checks if a given character can be represented as a valid 7–bit 
 * US-ASCII character
 *
 * @param c The character to check.
 * @return  1 if the character is ASCII, 0 otherwise.
 */
int	ft_isascii(int arg)
{
	return (arg >= 0 && arg <= 127);
}
