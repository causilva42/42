/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/12 16:35:49 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/16 15:07:16 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/**
 * @brief Counts the number of nodes in the list.
 *
 * @param lst The beginning of the list.
 *
 * @return The length (number of nodes) of the list.
 */
int	ft_lstsize(t_list *lst)
{
	int		num_nodes;

	if (lst == NULL)
		return (0);
	num_nodes = 0;
	while (lst != NULL)
	{
		num_nodes++;
		lst = lst->next;
	}
	return (num_nodes);
}
