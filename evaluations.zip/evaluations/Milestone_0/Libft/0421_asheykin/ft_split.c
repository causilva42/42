/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 22:01:28 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/21 10:22:06 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_length_of_word(const char *s, char c)
{
	int	i;

	i = 0;
	while (s[i] != '\0' && s[i] != c)
		i++;
	return (i);
}

static int	ft_word_count(const char *s, char c)
{
	int	i;
	int	len;
	int	word_count;

	i = 0;
	word_count = 0;
	while (s[i] != '\0')
	{
		while (s[i] == c)
			i++;
		len = ft_length_of_word(s + i, c);
		if (len > 0)
			word_count++;
		i += len;
	}
	return (word_count);
}

static char	*ft_strndup(const char *s, int n)
{
	int		i;
	char	*dest;

	i = 0;
	dest = (char *)malloc((n + 1) * sizeof(char));
	if (dest == NULL)
		return (NULL);
	while (s[i] && i < n)
	{
		dest[i] = s[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

/**
 * @brief Splits a string into an array of strings using a delimiter.
 *
 * Allocates memory and returns an array of strings obtained by splitting 
 * the input string 's' at each occurrence of the delimiter character 'c'.
 * The resulting array is null-terminated. Memory is allocated using malloc.
 *
 * @param s The string to be split.
 * @param c The delimiter character.
 * @return An array of newly allocated strings. NULL if allocation fails.
 */
char	**ft_split(char const *s, char c)
{
	int		i;
	int		j;
	int		len;
	char	**output;

	if (s == NULL)
		return (NULL);
	i = 0;
	j = 0;
	output = (char **)malloc((ft_word_count(s, c) + 1)
			* sizeof(char *));
	if (output == NULL)
		return (NULL);
	while (s[i] != '\0')
	{
		while (s[i] == c)
			i++;
		len = ft_length_of_word(s + i, c);
		if (len > 0)
			output[j++] = ft_strndup(s + i, len);
		i += len;
	}
	output[j] = NULL;
	return (output);
}
