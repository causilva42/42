/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asheykin <asheykin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 10:31:13 by asheykin          #+#    #+#             */
/*   Updated: 2025/04/13 11:27:40 by asheykin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Checks if a character is a digit.
 *
 * @param c The character to check.
 * @return  1 if the character is a digit, 0 otherwise.
 */
int	ft_isdigit(int arg)
{
	return (arg >= '0' && arg <= '9');
}
