/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vibarre <vibarre@student.42lisboa.com      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 12:08:34 by vibarre           #+#    #+#             */
/*   Updated: 2025/05/03 12:08:48 by vibarre          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

# include <stdio.h>
# include <unistd.h>
# include <stdint.h>
# include <stdlib.h>
# include <string.h>

# define ULONG_MAX 4294967295
# define B_DEC "0123456789"
# define B_HEX "0123456789abcdef"
# define B_HEXUP "0123456789ABCDEF"

int		ft_putchar_fd(char c, int fd);
int		ft_putnbr_base_fd(unsigned long n, char *base, int fd);
int		ft_putnbr_fd(int n, int fd);
int		ft_putptr_fd(void *ptr, int fd);
int		ft_putstr_fd(char *s, int fd);
size_t	ft_strlen(const char *s);

#endif // LIBFT_H
