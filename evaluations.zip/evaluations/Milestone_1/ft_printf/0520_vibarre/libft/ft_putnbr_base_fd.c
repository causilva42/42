/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base_fd.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vibarre <vibarre@student.42lisboa.com      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/03 12:12:05 by vibarre           #+#    #+#             */
/*   Updated: 2025/05/03 12:12:06 by vibarre          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	_putnbr_base(unsigned long n, char *base, int fd)
{
	unsigned long	lbase;
	int				i;

	i = 0;
	lbase = ft_strlen(base);
	if (n > (lbase - 1))
		i += _putnbr_base((n / lbase), base, fd);
	ft_putchar_fd((char)(base[n % lbase]), fd);
	return (i + 1);
}

int	ft_putnbr_base_fd(unsigned long n, char *base, int fd)
{
	return (_putnbr_base(n, base, fd));
}
