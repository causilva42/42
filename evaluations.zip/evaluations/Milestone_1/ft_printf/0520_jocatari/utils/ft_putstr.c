/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/19 11:11:56 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 16:36:21 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Writes a string to the specified file descriptor.
 *
 * This function writes the string @p s to the file descriptor @p fd.
 * It validates both the string and the file descriptor.
 *
 * @param s The string to be written.
 * @param fd The file descriptor to write the string.
 * @return The total number of characters written or -1 if @p fd is invalid.
 * 
 * @note Internal functions: `ft_strlen`.
 * @par Use case: Writing complete strings (error messages, debug prints) 
 * to a chosen FD, keeping your output routines consistent 
 * and avoiding `printf` overhead.
 */

#include "utils.h"

ssize_t	ft_putstr(const char *s, int fd)
{
	ssize_t	count;

	if (fd < 0)
		return (-1);
	if (s == NULL)
		return (write(fd, "(null)", 6));
	count = write(fd, s, ft_strlen(s));
	return (count);
}
