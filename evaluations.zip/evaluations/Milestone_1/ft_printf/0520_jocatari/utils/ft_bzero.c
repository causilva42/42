/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/11 11:51:03 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/19 21:44:49 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Sets the first n bytes of a memory area to zero.
 *
 * This function zeroes out the first @p n bytes of the memory area pointed 
 * to by @p s.
 *
 * @param s Pointer to the memory area to zero.
 * @param n Number of bytes to set to zero.
 * @note Use case: Legacy code that zeroes a memory block; functionally 
 * identical to memset(s, 0, n).
 */

#include "utils.h"

void	ft_bzero(void *s, size_t n)
{
	unsigned char	*ptr;
	size_t			i;

	ptr = (unsigned char *) s;
	i = 0;
	while (i < n)
	{
		ptr[i] = 0;
		i++;
	}
}
