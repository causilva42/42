/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putptr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/19 11:29:31 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 16:41:03 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**                                               
 * @brief Writes a pointer address to the specified file descriptor.
 *
 * This function writes the pointer address @p ptr to the file descriptor @p fd, 
 * converting it to hexadecimal (lowercase). It validates the file descriptor 
 * and handles NULL pointers.
 *
 * @param ptr The pointer address to be written.
 * @param fd The file descriptor to write to.
 * @return The total number of characters written or -1 if @p fd is invalid.
 * 
 * @note Internal functions: `ft_putstr`, `ft_putnbr`, `ft_strlen`.
 * External functions: `write`.
 * @par Use case: Writing memory addresses in hexadecimal to a file descriptor, 
 * useful for debugging or logging pointer values.
 */

#include "utils.h"

ssize_t	ft_putptr(void *ptr, char *base_digits, int fd)
{
	size_t	num;
	ssize_t	count;
	char	s[18];

	if (fd < 0)
		return (-1);
	if (ptr == NULL)
		return (write(fd, "(nil)", 5));
	num = (size_t)ptr;
	count = write(fd, "0x", 2);
	ft_bzero(s, 18);
	process_nbr(num, 0, s, base_digits);
	count += write(fd, s, ft_strlen(s));
	return (count);
}
