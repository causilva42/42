/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 19:36:20 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 16:20:27 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UTILS_H
# define UTILS_H

# include <stdlib.h>
# include <unistd.h>
# include <stddef.h>
# include <stdarg.h>
# include <limits.h>

# define B10 "0123456789"
# define B16 "0123456789abcdef"
# define B16U "0123456789ABCDEF"

void	ft_bzero(void *s, size_t n);
void	process_nbr(size_t n, int isneg, char *s, char *base_digits);
ssize_t	ft_format(const char *str, size_t *i, va_list *args);
ssize_t	ft_putstr(const char *s, int fd);
ssize_t	ft_putnbr(int n, char *base_digits, int fd);
ssize_t	ft_putunbr(size_t n, char *base_digits, int fd);
ssize_t	ft_putptr(void *n, char *base_digits, int fd);
size_t	ft_strlen(const char *s);

#endif
