/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 10:17:44 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/19 01:48:00 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Computes the length of a string.
 *
 * Calculates the number of characters in the null-terminated string @p s,
 * excluding the terminating null byte.
 *
 * @param s The string whose length is to be computed.
 * @return size_t The number of characters in @p s.
 * @note Use case: Determining buffer sizes dynamically (e.g. to allocate 
 * or format output).
 */

#include "utils.h"

size_t	ft_strlen(const char *s)
{
	size_t	l;

	l = 0;
	while (s[l])
		l++;
	return (l);
}
