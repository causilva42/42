/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_process_nbr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocatari <jocatari@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/19 19:51:58 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/19 21:57:20 by jocatari         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Converts a number to a string representation in a given base.
 *
 * This function converts the unsigned number @p n into its string
 * representation using the digit characters specified in @p base_digits.
 * The conversion supports any numerical base defined by @p base_digits
 * (e.g., "0123456789" for decimal or "0123456789abcdef" for hexadecimal).
 * Additionally, if @p isneg is nonzero, a '-' sign is prepended to
 * the resulting string.
 *
 * The function writes the converted number into the buffer @p s,
 * ensuring that the string is properly null-terminated.
 *
 * @param n           The unsigned number to be converted.
 * @param isneg       A flag indicating whether the number is negative
 * (nonzero for negative).
 * @param s           The buffer where the converted string will be stored.
 * @param base_digits A string containing digit characters defining
 * the numerical base.
 * @return void.
 * 
 * @note The function does not allocate memory for @p s; it is assumed that
 * the buffer is sufficiently large to hold the resulting string.
 * 
 * @note Internal functions: `ft_strlen`.
 * @par Use case: Convert a number to its string representation in
 * various bases (e.g., decimal, hex)
 */

#include "utils.h"

void	process_nbr(size_t n, int isneg, char *s, char *base_digits)
{
	size_t	m;
	int		i;
	int		base;

	m = n;
	i = 0;
	base = ft_strlen(base_digits);
	while (n > 0)
	{
		n /= base;
		++i;
	}
	if (m > 0)
		s[i--] = '\0';
	else
		s[i + 1] = '\0';
	while ((i + isneg) > 0 && m > 9)
	{
		s[i + isneg] = base_digits[m % base];
		m /= base;
		i--;
	}
	s[i + isneg] = base_digits[m % base];
	if (isneg)
		s[i] = '-';
}
