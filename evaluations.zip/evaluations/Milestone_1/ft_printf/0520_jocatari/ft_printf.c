/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 10:57:17 by jocatari          #+#    #+#             */
/*   Updated: 2025/05/20 17:57:47 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/**
 * @brief Formats and writes data to standard output.
 *
 * This function parses the format string `str`, processing conversion 
 * specifiers (preceded by `%`) and writing the corresponding arguments 
 * to stdout. Supported specifiers are: 
 * `c`, `s`, `p`, `d`/`i`, `u`, `x`/`X`, and `%%`.
 *
 * @param str Format string containing text and conversion specifiers.
 * @return int Total number of bytes written, or -1 if an unsupported 
 * specifier is encountered.
 * 
 * @par Use case: CLI application logging with timestamp, user, 
 * and session pointer.
 * E.g. `ft_printf("[%s] User %s (session %p) logged in.\n", 
 * get_time_str(), user, session);`
 */

#include "ft_printf.h"

int	ft_printf(const char *str, ...)
{
	va_list	args;
	ssize_t	count;
	ssize_t	write_val;
	size_t	i;

	if (!str[0])
		return (0);
	va_start(args, str);
	i = 0;
	count = 0;
	while (str[i])
	{
		if (str[i] == '%')
			write_val = ft_format(str, &i, &args);
		else
			write_val = write(STDOUT_FILENO, &(str[i++]), 1);
		if (write_val < 0)
			return (-1);
		count += write_val;
	}
	va_end(args);
	return (count);
}
