#!/bin/bash

# Usage: ./unique_randoms.sh <n> <min> <max>
# Example: ./unique_randoms.sh 10 -100 100

n=$1
min=$2
max=$3

# Ensure all arguments are provided
if [ $# -ne 3 ]; then
    echo "Usage: $0 <count> <min> <max>"
    exit 1
fi

range_size=$((max - min + 1))

# Check if the range is large enough
if [ "$n" -gt "$range_size" ]; then
    echo "Error: Cannot generate $n unique numbers in range [$min, $max]."
    exit 1
fi

# Use associative array to ensure uniqueness
declare -A numbers

while [ "${#numbers[@]}" -lt "$n" ]; do
    rand=$((RANDOM << 15 | RANDOM))  # Get a large enough random value
    rand=$((rand % range_size + min))
    numbers["$rand"]=1
done

# Print the unique random numbers
echo "${!numbers[@]}"