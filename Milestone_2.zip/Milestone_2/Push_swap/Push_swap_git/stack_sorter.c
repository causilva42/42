/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_sorter.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/20 14:56:08 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 17:46:15 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	stack_sorter(t_arr stack_a, t_arr stack_b)
{
	t_stk_stats	stk_stats[12];
	t_arr		stacks_copy[2];
	int			goal;
	int			move_counter;
	
	stk_stats[0] = get_stk_stats(stack_a);
	stacks_copy[0].ptr = malloc(stack_a.size * sizeof(int));
	stacks_copy[1].ptr = malloc(stack_a.size * sizeof(int));
	if (!stacks_copy[0].ptr || !stacks_copy[1].ptr)
		return (free(stacks_copy[0].ptr), free(stacks_copy[1].ptr), -1);
	goal = stack_a.size;
	move_counter = 0;
	while (stk_stats[0].lis_arr.size < goal)
	{
		fill_possibilities(stk_stats, stack_a, stack_b, stacks_copy);
		compare_stats()
		apply_operation()
		move_counter++;
	}
	move_counter += adjust_rotation(stack_a);
	free(stacks_copy[0].ptr);
	free(stacks_copy[1].ptr);
	return (move_counter);
}

void	fill_possibilities(t_stk_stats stk_stats[12], t_arr stack_a, t_arr stack_b, t_arr stacks_copy[2])
{
	apply_operation("sa", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("sb", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("ss", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("pa", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("pb", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("ra", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("rb", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("rr", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("rra", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("rrb", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
	apply_operation("rrr", stackscpy(stacks_copy, stacks));
	stk_stats[1] = get_stk_stats();
}

calc1 calc2
cpy0  calc2
cpy1  calc2

calc1 calc2
calc1 calc2

cpy0  calc2
cpy0  calc2
cpy0  calc2
cpy0  calc2
cpy0  calc2
cpy0  calc2
