/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argv_parser.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/18 12:04:26 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 11:37:04 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	string_arg_counter(const char *str, int *size);
int	string_parser(const char *str, t_arr *stack_a);
int	readstr_atoi(const char *str, int *num);
int	last_is_dupli(t_arr *stack_a);
int	ft_isdigit(int c);

int	argv_parser(int argc, char **argv, t_arr *stack_a, t_arr *stack_b)
{
	int	size;
	int	i;

	if (argc <= 0 || !argv || !stack_a || !stack_b)
		return (-1);
	size = 0;
	i = 0;
	while (++i < argc)
		if (string_arg_counter(argv[i], &size) == -1)
			return (free(stack_a->ptr), free(stack_b->ptr), -1);
	stack_a->ptr = malloc(size * sizeof(int));
	stack_b->ptr = malloc(size * sizeof(int));
	if (!stack_a->ptr || !stack_b->ptr)
		return (free(stack_a->ptr), free(stack_b->ptr), -1);
	stack_a->size = 0;
	stack_b->size = 0;
	i = 0;
	while (++i < argc)
		if (string_parser(argv[i], stack_a) == -1)
			return (free(stack_a->ptr), free(stack_b->ptr), -1);
	return (0);
}

int	string_arg_counter(const char *str, int *size)
{
	int	i;

	if (!str || !size)
		return (-1);
	i = 0;
	while (str[i] != '\0')
	{
		i += (str[i] == '-');
		if (!ft_isdigit(str[i]))
			return (-1);
		while (ft_isdigit(str[i]))
			i++;
		(*size)++;
		if (str[i] != ' ' && str[i] != '\0')
			return (-1);
		i += (str[i] == ' ');
	}
	return (0);
}

int	string_parser(const char *str, t_arr *stack_a)
{
	int	i;
	int	temp;

	if (!str || !stack_a || !stack_a->ptr)
		return (-1);
	i = 0;
	while (str[i] != '\0')
	{
		temp = readstr_atoi(&str[i], stack_a->ptr + stack_a->size++);
		if (temp == -1 || last_is_dupli(stack_a))
			return (-1);
		i += temp + (str[i] == ' ');
	}
	return (0);
}

int	readstr_atoi(const char *str, int *num)
{
	long	result;
	int		minus;
	int		i;

	if (!str || !num)
		return (-1);
	result = 0;
	minus = (str[0] == '-');
	i = minus;
	while (ft_isdigit(str[i]))
	{
		result = result * 10 + (str[i++] - '0');
		if (result > ((long) INT_MAX * !minus - (long) INT_MIN * minus))
			return (-1);
	}
	*num = result * (!minus - minus);
	return (i);
}

int	last_is_dupli(t_arr *stack_a)
{
	int	i;

	if (!stack_a || !stack_a->ptr)
		return (-1);
	i = 0;
	while (i < stack_a->size - 1)
	{
		if (stack_a->ptr[i] == stack_a->ptr[stack_a->size - 1])
			return (-1);
		i++;
	}
	return (0);
}

int	ft_isdigit(int c)
{
	return ((c >= '0' && c <= '9'));
}
