/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_ops.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/20 16:43:37 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 17:56:31 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	apply_operation(char *op, t_arr stacks[2])
{
	if (strcmp("sa", op) == 0)
		swap(stacks);
	else if (strcmp("sb", op) == 0)
		swap(stacks + 1);
	else if (strcmp("ss", op) == 0)
		(swap(stacks), swap(stacks + 1));
	else if (strcmp("pa", op) == 0)
		push(stacks + 1, stacks);
	else if (strcmp("pb", op) == 0)
		push(stacks, stacks + 1);
	else if (strcmp("ra", op) == 0)
		rotate(stacks);
	else if (strcmp("rb", op) == 0)
		rotate(stacks + 1);
	else if (strcmp("rr", op) == 0)
		(rotate(stacks), rotate(stacks + 1));
	else if (strcmp("rra", op) == 0)
		reverse_rotate(stacks);
	else if (strcmp("rrb", op) == 0)
		reverse_rotate(stacks + 1);
	else if (strcmp("rrr", op) == 0)
		(reverse_rotate(stacks), reverse_rotate(stacks + 1));
}

int	swap(t_arr *stack)
{
	int	temp;

	if (!stack || !stack->ptr)
		return (-1);
	if (stack->size <= 1)
		return (0);
	temp = stack->ptr[0];
	stack->ptr[0] = stack->ptr[1];
	stack->ptr[1] = temp;
	return (0);
}

int	push(t_arr *stack_from, t_arr *stack_to)
{
	if (!stack_from || !stack_from->ptr || !stack_to || !stack_to->ptr)
		return (-1);
	memcpy(stack_to->ptr, stack_to->ptr + 1, stack_to->size);
	stack_to->ptr[0] = stack_from->ptr[0];
	stack_to->size++;
	memcpy(stack_from->ptr + 1, stack_from->ptr, stack_from->size - 1);
	stack_from->size--;
	return (0);
}

int	rotate(t_arr *stack)
{
	int	temp;

	if (!stack || !stack->ptr)
		return (-1);
	temp = stack->ptr[0];
	memcpy(stack->ptr + 1, stack->ptr, stack->size - 1);
	stack->ptr[stack->size - 1] = temp;
	return (0);
}

int	reverse_rotate(t_arr *stack)
{
	int	temp;

	if (!stack || !stack->ptr)
		return (-1);
	temp = stack->ptr[stack->size - 1];
	memcpy(stack->ptr, stack->ptr + 1, stack->size - 1);
	stack->ptr[0] = temp;
	return (0);
}
