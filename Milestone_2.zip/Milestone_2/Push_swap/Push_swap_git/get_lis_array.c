/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_lis.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/23 10:49:11 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 14:27:32 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	prep(t_arr stack, t_arr *ext_stack, t_arr *lis_val, t_arr *prev_i);
static int	reset_vars(t_arr lis_val, t_arr prev_i);
static int	exec_lis(t_arr stack, t_arr lis_val, t_arr prev_i);
static t_arr	get_newresult(t_arr stack, t_arr lis_val, t_arr prev_i);

t_arr	get_lis_array(t_arr stack)
{
	t_arr	ext_stack;
	t_arr	lis_val;
	t_arr	prev_i;
	t_arr	result;
	int		i;

	if (prep(stack, &ext_stack, &lis_val, &prev_i) == -1)
		return ((t_arr){-1, NULL});
	result = (t_arr){0, NULL};
	i = 0;
	while (i < stack.size)
	{
		reset_vars(lis_val, prev_i);
		if (exec_lis((t_arr){stack.size, &ext_stack.ptr[i]}, lis_val, prev_i) > result.size)
		{
			free(result.ptr);
			result = get_newresult((t_arr){stack.size, &ext_stack.ptr[i]}, lis_val, prev_i);
		}
		i++;
	}
	free(ext_stack.ptr);
	free(lis_val.ptr);
	free(prev_i.ptr);
	return (result);
}

static int	prep(t_arr stack, t_arr *ext_stack, t_arr *lis_val, t_arr *prev_i)
{
	int	temp;
	int	i;

	if (!stack.ptr || stack.size <= 0)
		return (-1);
	temp = stack.size * 2 - 1;
	*ext_stack = (t_arr){temp, malloc(temp * sizeof(int))};
	*lis_val = (t_arr){stack.size, malloc(stack.size * sizeof(int))};
	*prev_i = (t_arr){stack.size, malloc(stack.size * sizeof(int))};
	if (!ext_stack->ptr || !lis_val->ptr || !prev_i->ptr)
	{
		free(ext_stack->ptr);
		free(lis_val->ptr);
		free(prev_i->ptr);
		return (-1);
	}
	i = -1;
	while (++i < stack.size)
		ext_stack->ptr[i] = stack.ptr[i];
	i = -1;
	while (++i < stack.size - 1)
		ext_stack->ptr[stack.size + i] = stack.ptr[i];
	return (0);
}

static int	reset_vars(t_arr lis_val, t_arr prev_i)
{
	int	size;
	int	i;

	size = lis_val.size;
	i = 0;
	while (i < size)
	{
		lis_val.ptr[i] = 1;
		prev_i.ptr[i] = -1;
		i++;
	}
	return (0);
}

static int	exec_lis(t_arr stack, t_arr lis_val, t_arr prev_i)
{
	int	final_value;
	int	i;
	int	j;

	i = 0;
	while (i < stack.size)
	{
		j = 0;
		while (j < i)
		{
			if (stack.ptr[j] < stack.ptr[i] && lis_val.ptr[j] >= lis_val.ptr[i])
			{
				lis_val.ptr[i] = lis_val.ptr[j] + 1;
				prev_i.ptr[i] = j;
			}
			j++;
		}
		i++;
	}
	final_value = 0;
	i = -1;
	while (++i < stack.size)
		if (lis_val.ptr[i] > final_value)
			final_value = lis_val.ptr[i];
	return (final_value);
}

static t_arr	get_newresult(t_arr stack, t_arr lis_val, t_arr prev_i)
{
	t_arr	result;
	int		last_i;
	int		i;

	last_i = 0;
	i = -1;
	while (++i < stack.size)
		if (lis_val.ptr[i] > lis_val.ptr[last_i])
			last_i = i;
	result.size = lis_val.ptr[last_i];
	result.ptr = malloc(lis_val.ptr[last_i] * sizeof(int));
	if (!result.ptr)
		return ((t_arr){-1, NULL});
	i = result.size - 1;
	while (i >= 0)
	{
		result.ptr[i] = stack.ptr[last_i];
		last_i = prev_i.ptr[last_i];
		i--;
	}
	return (result);
}
