/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/16 13:47:47 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 11:37:11 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char **argv)
{
	t_arr	stack_a;
	t_arr	stack_b;
	int		parser_return;
	int		sorter_return;

	parser_return = argv_parser(argc, argv, &stack_a, &stack_b);
	if (parser_return == -1)
	{
		write(2, "Error\n", 6);
		return (0);
	}
	sorter_return = stack_sorter(stack_a, stack_b);
	if (sorter_return == -1)
	{
		write(2, "Failed Sort\n", 12);
		return (free(stack_a.ptr), free(stack_b.ptr), 0);
	}
	free(stack_a.ptr);
	free(stack_b.ptr);
	return (0);
}
