/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/16 13:49:01 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 17:59:04 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <unistd.h>
# include <stdlib.h>
# include <limits.h>

typedef struct s_arr
{
	int	size;
	int	*ptr;
}	t_arr;

typedef struct s_stk_stats
{
	t_arr	lis_arr;
	int		trash;
	int		moves_to_add;
	int		moves_to_rm;
}	t_stk_stats;

int		argv_parser(int argc, char **argv, t_arr *stack_a, t_arr *stack_b);
int		stack_sorter(t_arr stack_a, t_arr stack_b);
t_arr	get_lis_array(t_arr stack);
int		apply_operation(char *op, t_arr stacks[2]);

#endif