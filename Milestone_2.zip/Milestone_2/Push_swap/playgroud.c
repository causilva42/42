/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   playgroud.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/18 17:25:45 by causilva          #+#    #+#             */
/*   Updated: 2025/06/23 16:06:34 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <limits.h>

#include "Push_swap_git/push_swap.h"
int	string_parser(const char *str, t_arr *stack_a);
int	readstr_atoi(const char *str, int *num);
int	ft_isdigit(int c);

int	main(int argc, char **argv)
{
	(void)argc;
	t_arr stack;
	t_arr result;
	int i;

	stack.size = 0;
	stack.ptr = malloc(500 * sizeof(int));
	string_parser(argv[1], &stack);
	result = get_lis_array(stack);
	i = 0;
	while (i < result.size)
		printf("%d\n", result.ptr[i++]);
	free(stack.ptr);
	free(result.ptr);
	return (0);
}

int	string_parser(const char *str, t_arr *stack_a)
{
	int	i;
	int	temp;

	if (!str || !stack_a || !stack_a->ptr)
		return (-1);
	i = 0;
	while (str[i] != '\0')
	{
		temp = readstr_atoi(&str[i], stack_a->ptr + stack_a->size++);
		if (temp == -1)
			return (-1);
		i += temp;
		i += (str[i] == ' ');
	}
	return (0);
}

int	readstr_atoi(const char *str, int *num)
{
	long	result;
	int		minus;
	int		i;

	if (!str || !num)
		return (-1);
	result = 0;
	minus = (str[0] == '-');
	i = minus;
	while (ft_isdigit(str[i]))
	{
		result = result * 10 + (str[i++] - '0');
		if (result > ((long) INT_MAX * !minus - (long) INT_MIN * minus))
			return (-1);
	}
	*num = result * (!minus - minus);
	return (i);
}

int	ft_isdigit(int c)
{
	return ((c >= '0' && c <= '9'));
}
