/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/15 09:41:48 by causilva          #+#    #+#             */
/*   Updated: 2025/09/04 16:48:37 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	init_vars(t_vars *vars, char *filename);
int	init_sprites(t_vars *vars);

int	main(int argc, char **argv)
{
	t_vars	vars;

	if (argc != 2)
		return (ft_printf("Error\nMain: number of args != 2\n"), 1);
	if (init_vars(&vars, argv[1]) == -1)
		return (1);
	mlx_hook(vars.win, 17, 0L, my_close, &vars);
	mlx_key_hook(vars.win, key_handler, &vars);
	mlx_loop_hook(vars.mlx, next_frame, &vars);
	mlx_loop(vars.mlx);
	return (0);
}

int	init_vars(t_vars *vars, char *filename)
{
	float	win_ratio;
	//int		x;

	if (parse_map(&(vars->map), filename) == -1)
		return (my_close(vars), -1);
	if (!(vars->mlx = mlx_init()))
		return (my_close(vars), ft_printf("Error\nInit_vars: failed to init mlx\n"), -1);
	win_ratio = (float) vars->map.size.x / vars->map.size.y;
	if (win_ratio >= 1920.0f / 1080)
		vars->win_size = (t_coord){1920, (int)(1920 / win_ratio)};
	else
		vars->win_size = (t_coord){(int)(1080 * win_ratio), 1080};
	if (!(vars->win = mlx_new_window(vars->mlx, vars->win_size.x, vars->win_size.y, "So_Long")))
		return (my_close(vars), ft_printf("Error\nInit_vars: failed to open window\n"), -1);
	vars->main_img.img = mlx_new_image(vars->mlx, vars->win_size.x, vars->win_size.y);
	vars->main_img.addr = mlx_get_data_addr(vars->main_img.img,
								&vars->main_img.bits_per_pixel,
								&vars->main_img.line_length,
								&vars->main_img.endian);
	if (init_sprites(vars) == -1)
		return (my_close(vars), -1);
	vars->move_count = 0;
	vars->finished = 0;
	return (0);
}

int	init_sprites(t_vars *vars)
{
	vars->sprites[EMPTY].img = mlx_xpm_file_to_image(vars->mlx,
		"../images/Untitled.xpm",
		&vars->sprites[EMPTY].res.x,
		&vars->sprites[EMPTY].res.y);
	vars->sprites[EMPTY].addr = mlx_get_data_addr(vars->sprites[EMPTY].img,
								&vars->sprites[EMPTY].bits_per_pixel,
								&vars->sprites[EMPTY].line_length,
								&vars->sprites[EMPTY].endian);
	vars->sprites[WALL].img = mlx_xpm_file_to_image(vars->mlx,
		"../images/Untitled.xpm",
		&vars->sprites[WALL].res.x,
		&vars->sprites[WALL].res.y);
	vars->sprites[WALL].addr = mlx_get_data_addr(vars->sprites[WALL].img,
								&vars->sprites[WALL].bits_per_pixel,
								&vars->sprites[WALL].line_length,
								&vars->sprites[WALL].endian);
	vars->sprites[COLLECTIBLE].img = mlx_xpm_file_to_image(vars->mlx,
		"../images/Untitled.xpm",
		&vars->sprites[COLLECTIBLE].res.x,
		&vars->sprites[COLLECTIBLE].res.y);
	vars->sprites[COLLECTIBLE].addr = mlx_get_data_addr(vars->sprites[COLLECTIBLE].img,
								&vars->sprites[COLLECTIBLE].bits_per_pixel,
								&vars->sprites[COLLECTIBLE].line_length,
								&vars->sprites[COLLECTIBLE].endian);
	vars->sprites[EXIT].img = mlx_xpm_file_to_image(vars->mlx,
		"../images/Untitled.xpm",
		&vars->sprites[EXIT].res.x,
		&vars->sprites[EXIT].res.y);
	vars->sprites[EXIT].addr = mlx_get_data_addr(vars->sprites[EXIT].img,
								&vars->sprites[EXIT].bits_per_pixel,
								&vars->sprites[EXIT].line_length,
								&vars->sprites[EXIT].endian);
	vars->sprites[PLAYER].img = mlx_xpm_file_to_image(vars->mlx,
		"../images/Untitled.xpm",
		&vars->sprites[PLAYER].res.x,
		&vars->sprites[PLAYER].res.y);
	vars->sprites[PLAYER].addr = mlx_get_data_addr(vars->sprites[PLAYER].img,
								&vars->sprites[PLAYER].bits_per_pixel,
								&vars->sprites[PLAYER].line_length,
								&vars->sprites[PLAYER].endian);
	return (0);
}

int	my_close(t_vars *vars)
{
	// int	x;

	if (vars->map.data)
		free(vars->map.data);
	if (vars->mlx)
	{
		if (vars->main_img.img)
			mlx_destroy_image(vars->mlx, vars->main_img.img);
		// x = 0;
		// while (x < 5)
		// 	if (vars->sprites[x].img)
		// 		mlx_destroy_image(vars->mlx, vars->sprites[x++].img);
		if (vars->win)
			mlx_destroy_window(vars->mlx, vars->win);
		mlx_destroy_display(vars->mlx);
		free(vars->mlx);
	}
	exit (0);
}