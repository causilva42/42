/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/27 15:37:02 by causilva          #+#    #+#             */
/*   Updated: 2025/09/22 12:31:02 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	ft_strcmp(const char *s1, const char *s2)
{
	size_t	i;

	i = 0;
	while (1)
	{
		if (s1[i] == '\0' && s2[i] == '\0')
			return (0);
		if (((unsigned char *) s1)[i] != ((unsigned char *) s2)[i])
			return (((unsigned char *) s1)[i] - ((unsigned char *) s2)[i]);
		i++;
	}
	return (0);
}

char	*ft_rmbreak(char *s)
{
	int	len;

	if (s)
	{
		len = ft_strlen(s);
		if (s[len - 1] == '\n')
			s[len - 1] = '\0';
	}
	return (s);
}

int	ft_get_addr(t_coord posic, int size_x)
{
	return (posic.y * size_x + posic.x);
}
