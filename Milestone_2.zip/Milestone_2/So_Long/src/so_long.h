/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/18 14:46:40 by causilva          #+#    #+#             */
/*   Updated: 2025/09/22 12:29:10 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <limits.h>
# include <math.h>
# include "../mlx_extended/mlx/mlx.h"
# include "../libft_extended/ft_printf/ft_printf.h"
# include "../libft_extended/get_next_line/get_next_line.h"
# include "../libft_extended/libft/libft.h"

# define EMPTY 0
# define WALL 1
# define COLLECTIBLE 2
# define EXIT 3
# define PLAYER 4

typedef struct s_coord
{
	int	x;
	int	y;
}	t_coord;

typedef struct s_map
{
	char	*data;
	t_coord	size;
	t_coord	player;
	t_coord	exit;
	int		collectibles_count;
}	t_map;

typedef struct s_img
{
	void	*img;
	char	*addr;
	t_coord	res;
	int		bits_per_pixel;
	int		line_length;
	int		endian;
}	t_img;

typedef struct s_vars
{
	void	*mlx;
	void	*win;
	t_coord	win_size;
	t_map	map;
	t_img	main_img;
	t_img	sprites[5];
	int		move_count;
	int		finished;
}	t_vars;

//----------------------------------------------
//---------------------Main---------------------
//----------------------------------------------
int		my_close(t_vars *vars);

//----------------------------------------------
//------------------Parse_map-------------------
//----------------------------------------------
int		parse_map(t_map *map, char *filename);

//----------------------------------------------
//---------------------Game---------------------
//----------------------------------------------
int		key_handler(int keycode, t_vars *vars);
int		next_frame(t_vars *vars);

//----------------------------------------------
//--------------------Graphic-------------------
//----------------------------------------------
int		ft_strcmp(const char *s1, const char *s2);
char	*ft_rmbreak(char *s);

#endif