/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   graphics.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 14:42:31 by causilva          #+#    #+#             */
/*   Updated: 2025/09/04 16:21:51 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"
#define floor_texture (255 << 16 | 0 << 8 | 0)
#define wall_texture (0 << 16 | 255 << 8 | 0)
#define collectible_texture (0 << 16 | 0 << 8 | 255)
#define exit_texture (255 << 16 | 255 << 8 | 0)
#define player_texture (0 << 16 | 255 << 8 | 255)

//int		put_component(char comp, t_img *texture, t_vars *vars);
int		put_component(char comp, int texture, t_vars *vars);
int		put_square(t_coord posic_map, int texture, t_vars *vars);
void	my_mlx_pixel_put(t_img *img, int x, int y, int color);

int	next_frame(t_vars *vars)
{
	put_component('0', floor_texture, vars);
	put_component('1', wall_texture, vars);
	put_component('C', collectible_texture, vars);
	put_component('E', exit_texture, vars);
	put_component('P', player_texture, vars);
	mlx_put_image_to_window(vars->mlx, vars->win, vars->main_img.img, 0, 0);
	return (0);
}

int	put_component(char comp, int texture, t_vars *vars)
{
	t_coord	posic_map;
	t_map	map;

	map = vars->map;
	posic_map.y = 0;
	while (posic_map.y < map.size.y)
	{
		posic_map.x = 0;
		while (posic_map.x < map.size.x)
		{
			if (map.data[posic_map.y * map.size.x + posic_map.x] == comp)
			put_square(posic_map, texture, vars);
			posic_map.x++;
		}
		posic_map.y++;
	}
	return (0);
}

int	put_square(t_coord posic_map, int texture, t_vars *vars)
{
	t_coord	posic_img;
	t_map	map;
	
	map = vars->map;
	posic_img.y = (vars->win_size.y / map.size.y) * posic_map.y;
	while (posic_img.y < (vars->win_size.y / map.size.y) * (posic_map.y + 1))
	{
		posic_img.x = (vars->win_size.x / map.size.x) * posic_map.x;
		while (posic_img.x < (vars->win_size.x / map.size.x) * (posic_map.x + 1))
		{
			my_mlx_pixel_put(&vars->main_img, posic_img.x, posic_img.y, texture);
			posic_img.x++;
		}
		posic_img.y++;
	}
	return (0);
}

void	my_mlx_pixel_put(t_img *img, int x, int y, int color)
{
	char	*dst;

	dst = img->addr + (y * img->line_length + x * (img->bits_per_pixel / 8));
	*(unsigned int*)dst = color;
}
