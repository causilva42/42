/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_img_func_put.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 16:08:54 by causilva          #+#    #+#             */
/*   Updated: 2025/09/23 11:54:47 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft_mlx.h"

void	ft_img_func_put(t_img *img, t_coord pos, t_coord size, int (*f)(t_coordf))
{
	int			x;
	int			y;
	t_coordf	sub_pos;
	int			color;

	if(!img || !img->addr || !f)
		return ;
	y = 0;
	while (y != size.y)
	{
		x = 0;
		while (x != size.x)
		{
			if ((pos.x + x >= 0) && (pos.x + x < img->size.x)
				&& (pos.y + y >= 0) && (pos.y + y < img->size.y))
			{
				sub_pos.x = (float)(x) / size.x;
				sub_pos.y = (float)(y) / size.y;
				color = f(sub_pos);
				ft_img_pixel_put(img, (t_coord){pos.x + x, pos.y + y}, color);
			}
			x += (size.x > 0) - (size.x < 0);
		}
		y += (size.y > 0) - (size.y < 0);
	}
}
