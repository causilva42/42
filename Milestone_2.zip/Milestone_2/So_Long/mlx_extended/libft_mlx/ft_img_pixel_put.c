/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_img_pixel_put.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 17:42:25 by causilva          #+#    #+#             */
/*   Updated: 2025/09/23 17:37:34 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft_mlx.h"

void	ft_img_pixel_put(t_img *img, t_coord pos, int color)
{
	char		*dst;
	float		a;
	unsigned	r;
	unsigned	g;
	unsigned	b;

	dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
	a = 1 - (float)((unsigned)color >> 24) / 255;
	r = (((unsigned)color >> 16) & 0xFF) * a;
	r += ((*(unsigned *)dst >> 16) & 0xFF) * (1 - a);
	g = (((unsigned)color >> 8) & 0xFF) * a;
	g += ((*(unsigned *)dst >> 8) & 0xFF) * (1 - a);
	b = (((unsigned)color >> 0) & 0xFF) * a;
	b += ((*(unsigned *)dst >> 0) & 0xFF) * (1 - a);
	*(unsigned *)dst = (r << 16 | g << 8 | b);
}
/* 
void	ft_img_pixel_put(t_img *img, t_coord pos, int color)
{
	char	*dst;

	dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
	*(int *)dst = color;
}
 */
/* 
void	ft_img_pixel_put(t_img *img, t_coord pos, int color)
{
	char	*dst;

	if((img && img->addr)
		&& (pos.x >= 0) && (pos.x < img->size.x)
		&& (pos.y >= 0) && (pos.y < img->size.y))
	{
		dst = img->addr + (pos.y * img->line_length + pos.x * (img->bpp / 8));
		*(int *)dst = color;
	}
}
 */