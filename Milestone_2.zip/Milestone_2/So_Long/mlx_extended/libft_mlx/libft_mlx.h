/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft_mlx.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 11:54:41 by causilva          #+#    #+#             */
/*   Updated: 2025/09/22 16:59:24 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_MLX_H
# define LIBFT_MLX_H

# include <stdlib.h>
# include <math.h>
# include "../mlx/mlx.h"

typedef struct s_coord
{
	int	x;
	int	y;
}	t_coord;

typedef struct s_coordf
{
	float	x;
	float	y;
}	t_coordf;

typedef struct s_img
{
	void	*img;
	char	*addr;
	t_coord	res;
	int		bpp;
	int		line_length;
	int		endian;
}	t_img;

typedef struct s_vars
{
	void	*mlx;
	void	*win;
	t_img	img;
	t_img	img2;
}	t_vars;

unsigned int	linear_to_color_wheel(t_coordf wheel_pos);

void	ft_img_func_put(t_img *img, t_coord pos, t_coord size, unsigned int (*f)(t_coordf));
void	ft_img_img_put(t_img *img, t_coord pos, t_coord size, t_img *img2);
unsigned int	ft_img_pixel_get(t_img *img, t_coord pos);
void	ft_img_pixel_put(t_img *img, t_coord pos, unsigned int color);


#endif