/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: causilva <@student.42lisboa.com>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/15 09:41:48 by causilva          #+#    #+#             */
/*   Updated: 2025/09/04 15:11:05 by causilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft_mlx.h"

int		loop(t_vars *vars);
int		myclose(t_vars *vars);

int	main(void)
{
	t_vars	vars;

	vars.mlx = mlx_init();
	vars.win = mlx_new_window(vars.mlx, 1920, 1080, "So_Long");
	vars.img.res = (t_coord){1920,1080};
	vars.img.img = mlx_new_image(vars.mlx, 1920, 1080);
	vars.img.addr = mlx_get_data_addr(vars.img.img, &vars.img.bpp,
			&vars.img.line_length, &vars.img.endian);
	vars.img2.img = mlx_xpm_file_to_image(vars.mlx, "./Untitled.xpm", &vars.img2.res.x, &vars.img2.res.y);
	vars.img2.addr = mlx_get_data_addr(vars.img2.img, &vars.img2.bpp,
			&vars.img2.line_length, &vars.img2.endian);
	mlx_hook(vars.win, 17, 0L, myclose, &vars);
	mlx_loop_hook(vars.mlx, loop, &vars);
	mlx_loop(vars.mlx);
	return (0);
}

unsigned int	get_black(t_coordf wheel_pos)
{
	(void)wheel_pos;
	return (0xFF << 24);
}

int	loop(t_vars *vars)
{
	static int x = 0;

	ft_img_func_put(&vars->img, (t_coord){0,0}, vars->img.res, get_black);
	ft_img_img_put(&vars->img, (t_coord){x,x}, (t_coord){-100,-200}, &vars->img2);
	mlx_put_image_to_window(vars->mlx, vars->win, vars->img.img, 0, 0);
	x += 20;
	if(x == vars->img.res.x)
		x = 0;
	return (0);
}

int	myclose(t_vars *vars)
{
	mlx_destroy_image(vars->mlx, vars->img.img);
	mlx_destroy_image(vars->mlx, vars->img2.img);
	mlx_destroy_window(vars->mlx, vars->win);
	mlx_destroy_display(vars->mlx);
	free(vars->mlx);
	exit (0);
}
