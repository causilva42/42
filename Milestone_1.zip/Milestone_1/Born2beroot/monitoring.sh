#!/bin/bash

#Architecture
ARCH=$(uname -a)
#CPU physical
CPUF=$(lscpu | awk '/^Core\(s\) per socket:/ {c=$4} /^Socket\(s\):/ {s=$2} END {print c * s}')
#vCPU
CPUV=$(lscpu | awk '$1 == "CPU(s):" {print $2}')
#Memory Usage
RAM_USE=$(free -m | awk '$1 == "Mem:" {print $3}')
RAM_TOTAL=$(free -m | awk '$1 == "Mem:" {print $2}')
RAM_PERCENT=$(free -m | awk '$1 == "Mem:" {printf("%.2f"), $3/$2*100}')
#Disk Usage
DISK_USE=$(df -m | grep "^/dev/mapper/" | awk '{disk_u += $3} END {print disk_u}')
DISK_TOTAL=$(df -m | grep "^/dev/mapper/"  | awk '{disk_t += $2} END {printf ("%d"), disk_t/1024}')
DISK_PERCENT=$(df -m | grep "^/dev/mapper/"  | awk '{disk_u += $3} {disk_t+= $2} END {printf("%d"), disk_u/disk_t*100}')
#CPU load
CPUL=$(uptime | awk -v cores=$CPUV '{printf("%.1f", $9*100/cores)}')
#Last boot
LB=$(uptime -s | cut -c1-16)
#LVM use
LVMU=$(if [ $(lsblk | awk '$6 == "lvm"' | wc -l) -gt 0 ]; then echo yes; else echo no; fi)
#Connections TCP
TCPC=$(ss -H -t | grep "ESTAB" | wc -l)
#User log
ULOG=$(who | awk '{print $1}' | sort -u | wc -l)
#Network
IP=$(hostname -I | awk '{print $1}')
MAC=$(ip link | grep "link/ether" | awk '{print $2}')
#Sudo
CMDN=$(journalctl _COMM=sudo | grep COMMAND | wc -l)

wall "	#Architecture: $ARCH
	#CPU physical: $CPUF
	#vCPU: $CPUV
	#Memory Usage: $RAM_USE/${RAM_TOTAL}MB ($RAM_PERCENT%)
	#Disk Usage: $DISK_USE/${DISK_TOTAL}Gb ($DISK_PERCENT%)
	#CPU load: $CPUL%
	#Last boot: $LB
	#LVM use: $LVMU
	#Connections TCP: $TCPC ESTABLISHED
	#User log: $ULOG
	#Network: IP $IP ($MAC)
	#Sudo: $CMDN cmd"